# house-source
房源相关信息抓取

1.安居客爬虫启动方式

1.执行脚本,获取安居客所有的 城市-行政区-区域三级目录，数据会存储至location表（只需执行一次）
scrapy crawl location_anjuke
2.修改并执行utils.py，在start_shells生成scrapy的执行命令
3.启动scrapy crawl anjuke进行数据的抓取
