# -*- coding: utf-8 -*-

from twisted.internet import reactor, task
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging
from house_source.utils import Redis_utils
from house_source.spiders.tongcheng58_department import Tongcheng58_departmentSpider


OVER_FLAG_LIST = []

# 扫描频率
FREQUENCY = 60


def is_over():
    global OVER_FLAG_LIST
    global list_size
    global reactor
    flag_list_count = len(OVER_FLAG_LIST)
    result = Redis_utils.is_exist('department58:start_urls')
    if flag_list_count < list_size:
        OVER_FLAG_LIST.append(result)
    else:
        OVER_FLAG_LIST.pop(0)
        OVER_FLAG_LIST.append(result)
    if (not any(OVER_FLAG_LIST)) and (len(OVER_FLAG_LIST) == list_size):
        '''
        如果全为假，关闭爬虫
        '''
        reactor.stop()


def crawl_parse():
    runner.crawl(Tongcheng58_departmentSpider)


if __name__ == '__main__':
    settings = get_project_settings()
    debug = settings.get('PRJ_DEBUG')
    if debug:
        configure_logging({'LOG_FORMAT': '%(levelname)s: %(message)s'})
        list_size = 30
    else:
        configure_logging(
            {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/department58.log'})
        list_size = 60 * 4
    runner = CrawlerRunner(settings=settings)
    crawl_parse()
    lc = task.LoopingCall(is_over)
    lc.start(FREQUENCY, now=False)
    reactor.run()
