# -*- coding: utf-8 -*-

import os
import sys
from twisted.internet import reactor, defer, task
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging
from house_source.utils import Redis_utils, Time_utils, insertOrUpdateBatch, get_batch
from house_source.spiders.danke import DankeSpider

CURRENT_PATH = os.path.abspath(__file__)
CURRENT_DIR = os.path.dirname(CURRENT_PATH)

def clean_redis():
    '''
    清除上次爬虫产生的redis中的数据
    '''
    Redis_utils.del_keys("danke:dupefilter","danke:dupefilter")

if __name__ == '__main__':
    # batch = get_batch(u'蛋壳房源', 'houses2')
    insertOrUpdateBatch(u'蛋壳房源', 'houses2')
    settings = get_project_settings()
    debug = settings.get('PRJ_DEBUG')
    if debug:
        configure_logging({'LOG_FORMAT': '%(levelname)s: %(message)s'})
        # configure_logging(
        #     {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/danke.log'})
    else:
        configure_logging(
            {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/danke.log'})
    runner = CrawlerRunner(settings=settings)

    clean_redis()
    d = runner.crawl(DankeSpider)
    d.addBoth(lambda _: reactor.stop())
    reactor.run()

