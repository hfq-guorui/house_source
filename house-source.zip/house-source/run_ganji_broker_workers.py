# -*- coding: utf-8 -*-

from twisted.internet import reactor, task
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.utils import Redis_utils
from scrapy.utils.log import configure_logging
from house_source.spiders.ganji_broker import GanjiBrokerSpider


OVER_FLAG_LIST = []

# 扫描频率
FREQUENCY = 60


def is_over():
    '''
    判断爬虫结束条件
    '''
    global OVER_FLAG_LIST
    global list_size
    global reactor
    flag_list_count = len(OVER_FLAG_LIST)
    result = Redis_utils.is_exist('ganji_broker:start_urls')
    if flag_list_count < list_size:
        OVER_FLAG_LIST.append(result)
    else:
        OVER_FLAG_LIST.pop(0)
        OVER_FLAG_LIST.append(result)
    if (not any(OVER_FLAG_LIST)) and (len(OVER_FLAG_LIST) == list_size):
        '''
        如果全为假，关闭爬虫
        '''
        reactor.stop()


def crawl_parse():
    runner.crawl(GanjiBrokerSpider)


if __name__ == '__main__':
    settings = get_project_settings()
    debug = settings.get('PRJ_DEBUG')
    if debug:
        configure_logging(
            {'LOG_FORMAT': '%(levelname)s: %(message)s', 'LOG_LEVEL': 'INFO'})
        list_size = 3
    else:
        configure_logging(
            {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/ganji_broker.log'})
        list_size = 60 * 2
    runner = CrawlerRunner(settings=settings)
    crawl_parse()
    lc = task.LoopingCall(is_over)
    lc.start(FREQUENCY, now=False)
    reactor.run()
