# -*- coding: utf-8 -*-

import time
import re
from selenium import webdriver
from twisted.internet import reactor
from scrapy import Selector
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging
from house_source.spiders.mogu import MoguSpider
from house_source.utils import Redis_utils

CITYS = {
    'www': u'上海',
    'bj': u'北京',
    'sz': u'深圳',
    'hz': u'杭州',
    'nj': u'南京'
}


def get_max_page():
    start_urls = map(
        lambda x: 'http://{}.mogoroom.com/list/'.format(x), CITYS.keys())
    service_args = []
    service_args.append('--load-images=no')  # 关闭图片加载
    service_args.append('--disk-cache=yes')  # 开启缓存
    service_args.append('--ignore-ssl-errors=true')  # 忽略https错误
    driver = webdriver.PhantomJS(service_args=service_args)
    driver.implicitly_wait(10)
    driver.set_page_load_timeout(10)
    result = {}
    retry_time = 10
    for i in range(retry_time):
        if i != 0:
            time.sleep(5)
        for url in start_urls:
            driver.get(url)
            selector = Selector(text=driver.page_source)
            last_page = selector.xpath(
                '//nav[@class="pagination"]/ul/li[last()]/a/@href').extract_first()
            try:
                pageCount = int(re.search(r'(.*?)(\d+)', last_page).group(2))
            except:
                continue
            result[url] = pageCount
        if len(result) == 5:
            break
    driver.quit()
    return result

if __name__ == '__main__':
    settings = get_project_settings()
    runner = CrawlerRunner(settings=settings)
    # configure_logging({'LOG_FORMAT': '%(levelname)s: %(message)s'})
    configure_logging({'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/mogu.log'})
    max_page = get_max_page()
    Redis_utils.del_keys('mogu:dupefilter', 'mogu:dupefilter')
    d = runner.crawl(MoguSpider, max_page=max_page)
    d.addBoth(lambda _: reactor.stop())
    reactor.run()
