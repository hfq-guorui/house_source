# -*- coding: utf-8 -*-
import os
import sys
from twisted.internet import reactor, task
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging
from house_source.utils import Redis_utils, insertOrUpdateBatch
from house_source.spiders.location_department_58 import LocationDepartment58Spider
from house_source.spiders.p_department_58 import PDepartment58Spider
from house_source.spiders.tongcheng58_department import Tongcheng58_departmentSpider

CURRENT_PATH = os.path.abspath(__file__)

SHEDULE_CITY_ORDER = [u'北京', u'济南', u'青岛', u'郑州', u'西安',
                      u'成都', u'重庆', u'武汉', u'合肥', u'长沙', u'南京']


OVER_FLAG_LIST = []

# 扫描频率
FREQUENCY = 60


def clean_redis():
    Redis_utils.del_keys('department58:start_urls', 'p_department58:start_urls', 'department58:meta', 'p_department58:dupefilter',
                         'department58:dupefilter', 'location_department58:dupefilter')


def is_over(city):
    global OVER_FLAG_LIST
    global list_size
    global reactor
    flag_list_count = len(OVER_FLAG_LIST)
    result = Redis_utils.is_exist(
        'department58:start_urls') or Redis_utils.is_exist('p_department58:start_urls')
    if flag_list_count < list_size:
        OVER_FLAG_LIST.append(result)
    else:
        OVER_FLAG_LIST.pop(0)
        OVER_FLAG_LIST.append(result)
    if (not any(OVER_FLAG_LIST)) and (len(OVER_FLAG_LIST) == list_size):
        '''
        如果全为假，关闭爬虫
        '''
        reactor.stop()
        clean_redis()
        if city == SHEDULE_CITY_ORDER[-1]:
            pass
        else:
            current_city_index = SHEDULE_CITY_ORDER.index(city)
            next_city = SHEDULE_CITY_ORDER[current_city_index +
                                           1].encode('utf-8')
            os.system(
                '/usr/bin/sudo /usr/bin/python {path} {city}'.format(path=CURRENT_PATH, city=next_city))


def crawl(city):
    clean_redis()
    runner.crawl(LocationDepartment58Spider, city=city)
    runner.crawl(PDepartment58Spider)
    runner.crawl(Tongcheng58_departmentSpider)


if __name__ == '__main__':
    args = sys.argv
    if len(args) == 1:
        city = u'北京'
        insertOrUpdateBatch(u'58公寓', 'houses2')
    else:
        city = args[1].decode('utf-8')
    settings = get_project_settings()
    debug = settings.get('PRJ_DEBUG')
    if debug:
        configure_logging({'LOG_FORMAT': '%(levelname)s: %(message)s'})
        list_size = 2
    else:
        configure_logging(
            {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/department58.log'})
        list_size = 30
    runner = CrawlerRunner(settings=settings)
    crawl(city)
    lc = task.LoopingCall(is_over, city)
    lc.start(FREQUENCY, now=False)
    reactor.run()
