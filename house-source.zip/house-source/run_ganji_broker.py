# -*- coding: utf-8 -*-

import os
import sys
from twisted.internet import reactor, task
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging
from house_source.utils import Redis_utils, insertOrUpdateBatch
from house_source.spiders.location_ganji_broker import LocationGanjiBrokerSpider
from house_source.spiders.ganji_broker import GanjiBrokerSpider


CURRENT_PATH = os.path.abspath(__file__)

SHEDULE_CITY_ORDER = [u'北京', u'济南', u'青岛', u'郑州', u'西安',
                      u'成都', u'重庆', u'武汉', u'合肥', u'长沙', u'南京']


OVER_FLAG_LIST = []

# 扫描频率
FREQUENCY = 60


def clean_redis():
    Redis_utils.del_keys('ganji_broker:start_urls', 'ganji_broker:dupefilter',
                         'location_ganji_broker:dupefilter', 'location_ganji_broker:requests', 'ganji_broker:requests')


def is_over(city):
    '''
    判断爬虫结束条件
    '''
    global OVER_FLAG_LIST
    global list_size
    global reactor
    flag_list_count = len(OVER_FLAG_LIST)
    result = Redis_utils.is_exist('ganji_broker:start_urls')
    if flag_list_count < list_size:
        OVER_FLAG_LIST.append(result)
    else:
        OVER_FLAG_LIST.pop(0)
        OVER_FLAG_LIST.append(result)
    if (not any(OVER_FLAG_LIST)) and (len(OVER_FLAG_LIST) == list_size):
        '''
        如果全为假，关闭爬虫
        '''
        reactor.stop()
        clean_redis()
        if city == SHEDULE_CITY_ORDER[-1]:
            pass
        else:
            current_city_index = SHEDULE_CITY_ORDER.index(city)
            next_city = SHEDULE_CITY_ORDER[current_city_index +
                                           1].encode('utf-8')
            os.system(
                '/usr/bin/sudo /usr/bin/python {path} {city}'.format(path=CURRENT_PATH, city=next_city))


def crawl(city):
    clean_redis()
    runner.crawl(LocationGanjiBrokerSpider, city)
    runner.crawl(GanjiBrokerSpider)


if __name__ == '__main__':
    args = sys.argv
    if len(args) == 1:
        city = u'北京'
        insertOrUpdateBatch('赶集经纪人', 'houses')
    else:
        city = args[1].decode('utf-8')
    settings = get_project_settings()
    debug = settings.get('PRJ_DEBUG')
    if debug:
        configure_logging(
            {'LOG_FORMAT': '%(levelname)s: %(message)s', 'LOG_LEVEL': 'INFO'})
        list_size = 3
    else:
        configure_logging(
            {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/ganji_broker.log'})
        list_size = 30
    runner = CrawlerRunner(settings=settings)
    crawl(city)
    lc = task.LoopingCall(is_over, city)
    lc.start(FREQUENCY, now=False)
    reactor.run()
