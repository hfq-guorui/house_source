# -*- coding: utf-8 -*-

from twisted.internet import reactor
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging
from house_source.utils import Redis_utils, insertOrUpdateBatch
from house_source.spiders.xiangyu import Xiangyu
from house_source.spiders.xiangyu_bj import XiangyuBj

def clean_redis():
    '''
    清除上次爬虫产生的redis中的数据
    '''
    Redis_utils.del_keys("xiangyu:dupefilter","xiangyubj:dupefilter","xiangyubj:requests","xiangyu:requests")

def is_over():
    '''
    判断爬虫结束条件
    '''
    global OVER_FLAG_LIST
    global list_size
    global reactor

if __name__ == '__main__':
    clean_redis()
    insertOrUpdateBatch(u'相寓房源', 'houses2')
    settings = get_project_settings()
    debug = settings.get('PRJ_DEBUG')
    if debug:
        configure_logging({'LOG_FORMAT': '%(levelname)s: %(message)s'})
    else:
        configure_logging(
            {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/xiangyu.log', 'DOWNLOAD_TIMEOUT':120})
    runner = CrawlerRunner(settings=settings)
    runner.crawl(XiangyuBj)
    runner.crawl(Xiangyu)
    d = runner.join()
    d.addBoth(lambda _: reactor.stop())
    reactor.run()
