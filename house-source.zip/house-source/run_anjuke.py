# -*- coding: utf-8 -*-

import redis
from twisted.internet import reactor, defer, task
import scrapy
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging
from house_source.utils import Redis_utils, Time_utils, get_location
from house_source.spiders.location_anjuke import Location_AnjukeSpider
from house_source.spiders.p_anjuke import PAnjukeSpider
from house_source.spiders.anjuke import AnjukeSpider


def is_over(key):
    global count
    global reactor
    redis_host = settings.get('REDIS_HOST')
    redis_port = settings.get('REDIS_PORT')
    redis_db = settings.get('REDIS_DB')
    password = settings.get('REDIS_PASS')
    if debug:
        r = redis.StrictRedis(host=redis_host, port=redis_port, db=redis_db)
    else:
        r = redis.StrictRedis(host=redis_host, port=redis_port,
                              db=redis_db, password=password)
    if not r.exists(key):
        count += 1
    else:
        count = 0
    if count > 2:
        reactor.stop()
        Redis_utils.del_keys('anjuke:start_urls', 'anjuke:meta')


@defer.inlineCallbacks
def crawl():
    Redis_utils.del_keys('anjuke:start_urls', 'anjuke:meta')
    yield runner.crawl(Location_AnjukeSpider)
    locations = get_location(website=u'安居客', batch=TODAY)
    for location in locations:
        city = location[0]
        district = location[1]
        zone = location[2]
        yield runner.crawl(PAnjukeSpider, city=city,
                           district=district, zone=zone)

if __name__ == '__main__':
    count = 0
    TODAY = Time_utils.getNowDate()
    settings = get_project_settings()
    debug = settings.get('PRJ_DEBUG')
    if debug:
        configure_logging({'LOG_FORMAT': '%(levelname)s: %(message)s'})
    else:
        configure_logging(
            {'LOG_LEVEL': 'INFO', 'LOG_FILE': './logs/anjuke.log'})
    frequency = settings.get('SCAN_FREQUENCY')
    runner = CrawlerRunner(settings=settings)
    crawl()
    runner.crawl(AnjukeSpider)
    lc = task.LoopingCall(is_over, key='anjuke:start_urls')
    lc.start(frequency, now=False)
    reactor.run()
