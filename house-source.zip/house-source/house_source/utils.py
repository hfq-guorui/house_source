# -*- coding:utf-8 -*-

from collections import Counter
import requests
import random
import zlib
from datetime import datetime
import json
import redis
import pymongo
from settings import REDIS_HOST, REDIS_PORT, REDIS_DB, REDIS_PASS, MONGO_CONF, PROXY_DB, PRJ_DEBUG


class Redis_utils(object):

    @classmethod
    def __con_redis(cls):
        if PRJ_DEBUG:
            # 测试环境
            pool = redis.ConnectionPool(
                host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB)
            return redis.StrictRedis(connection_pool=pool)
        else:
            # 生产环境
            pool = redis.ConnectionPool(
                host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, password=REDIS_PASS)
            return redis.StrictRedis(connection_pool=pool)

    @classmethod
    def insert_url(cls, key, value):
        r = cls.__con_redis()
        if isinstance(value, list) or isinstance(value, set):
            return r.sadd(key, *value)
        else:
            return r.sadd(key, value)

    @classmethod
    def insert_meta(cls, key, field, value):
        r = cls.__con_redis()
        return r.hsetnx(key, field, value)

    @classmethod
    def get_meta(cls, key, field):
        r = cls.__con_redis()
        data = r.hget(key, field)
        return data

    @classmethod
    def get_meta_len(cls, key):
        r = cls.__con_redis()
        count = r.hlen(key)
        return count

    @classmethod
    def get_count(cls, key):
        r = cls.__con_redis()
        if r.exists(key):
            _type = r.type(key)
            if _type == 'set':
                count = r.scard(key)
            elif _type == 'list':
                count = r.llen(key)
            elif _type == 'hash':
                count = r.hlen(key)
            return count

    @classmethod
    def is_exist(cls, key):
        r = cls.__con_redis()
        return r.exists(key)

    @classmethod
    def del_keys(cls, *keyNames):
        r = cls.__con_redis()
        keys = filter(lambda x: r.exists(x), keyNames)
        for key in keys:
            r.delete(key)

    @classmethod
    def get_set_member(cls, key):
        r = cls.__con_redis()
        if r.exists(key) and r.type(key) == 'set':
            return r.smembers(key)

    @classmethod
    def rename_key(cls, field, old_key, new_key):
        r = cls.__con_redis()
        if r.hexists(field, old_key):
            value = r.hget(field, old_key)
            r.hdel(field, old_key)
            r.hset(field, new_key, value)

    @classmethod
    def statistic_meta(cls, key):
        '''
        meta计数器，统计meta信息中_id的数量,返回字典
        '''
        id_list = []
        r = cls.__con_redis()
        for k, v in r.hscan_iter(name=key, count=100):
            value = CompressData(v).decompress()
            parsed_id = json.loads(value).get('meta').get('_id')
            id_list.append(parsed_id)
        counter = Counter(id_list)
        return dict(counter)


class Proxis_utils(object):
    @classmethod
    def __con_redis(cls):
        if PRJ_DEBUG:
            # 测试环境
            return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=PROXY_DB)
        else:
            # 生产环境
            return redis.StrictRedis(
                host=REDIS_HOST, port=REDIS_PORT, db=PROXY_DB, password=REDIS_PASS)

    @classmethod
    def fetchProxies(cls):
        r = cls.__con_redis()
        if not r.exists('origin_proxies'):
            # 老代理
            range_port = range(81, 90)
            range_port.remove(88)
            origin_proxies = map(
                lambda port: 'http://vpn.itercast.com:88{}'.format(port), range_port)
            r.sadd('origin_proxies', *origin_proxies)
        if not r.exists('new_proxies') or r.scard('new_proxies') == 0:
            try:
                ret = requests.get(
                    'http://ppool.hzfapi.com/proxies', timeout=3)
                ip_list = ret.json().values()
                new_proxies = map(
                    lambda ip: 'http://{}:18118'.format(ip), ip_list)
                r.sadd('new_proxies', *new_proxies)
                r.expire('new_proxies', 60)
            except Exception as e:
                print e

    @classmethod
    def choiceProxy(cls):
        '''
        随机选择一个代理
        '''
        r = cls.__con_redis()
        proxies = list(r.smembers('origin_proxies'))
        if r.exists('new_proxies') and r.scard('new_proxies') > 0:
            new_proxies = list(r.smembers('new_proxies'))
            proxies.extend(new_proxies)
        proxy = random.choice(proxies)
        return proxy


class Mongo_utils(object):
    def __init__(self, db, collection):
        # 连接mongo
        self.mongo_host = MONGO_CONF.get('host')
        self.mongo_port = MONGO_CONF.get('port')
        self.mongo_user = MONGO_CONF.get('user', None)
        self.mongo_pass = MONGO_CONF.get('passwd', None)
        self.mongo_client = pymongo.MongoClient(
            host=self.mongo_host, port=self.mongo_port)
        self.mongo_db = self.mongo_client[db]
        # 生产环境
        if not PRJ_DEBUG:
            self.mongo_db.authenticate(
                self.mongo_user, self.mongo_pass, source='admin')
        self.collection = self.mongo_db[collection]

    def get_dbs(self):
        '''
        获取所有数据库
        '''
        return self.mongo_client.database_names()

    def get_collections(self):
        '''
        获取所有的集合
        '''
        return self.mongo_db.collection_names()

    def insert_data(self, data):
        if isinstance(data, list):
            result = self.collection.insert_many(data)
        elif isinstance(data, dict):
            result = self.collection.insert(data)
        else:
            pass
        return result

    def get_data(self, **condition):
        '''
        获取数据
        '''
        return self.collection.find(condition)

    def delete_data(self, **condition):
        '''
        删除数据
        '''
        return self.collection.remove(condition)

    def get_count(self, **condition):
        '''
        获取数据量
        '''
        return self.collection.find(condition).count()

    def get_max_data(self, key, **condition):
        return self.collection.find_one(condition, sort=[(key, pymongo.DESCENDING)])

    def get_min_data(self, key, **condition):
        return self.collection.find_one(condition, sort=[(key, pymongo.ASCENDING)])

    def statistic_actual_crawl_count(self):
        '''
        统计三级区域实际抓取的数量
        '''
        result_dict = {}
        pipeline = [
            {'$group': {'_id': '$p_monitor_id', 'count': {'$sum': 1}}}]
        result = list(self.collection.aggregate(pipeline))
        for i in result:
            key = str(i.get('_id'))
            value = i.get('count')
            result_dict[key] = value
        return result_dict


class Time_utils(object):
    @classmethod
    def getNowTime(cls):
        return datetime.now()

    @classmethod
    def getNowDate(cls):
        return datetime.now().strftime('%Y-%m-%d')

    @classmethod
    def str2date(cls, date):
        year_s, mon_s, day_s = date.split('-')
        return datetime(int(year_s), int(mon_s), int(day_s))


def get_batch(website, db_name):
    '''
    获取该网站的最大批次
    '''
    batch_conn = Mongo_utils(db_name, 'batch_info')
    batch = batch_conn.collection.find_one({'website': website}).get('batch')
    return batch


def insertOrUpdateBatch(website, db_name):
    '''
    将最新批次持久化到mongo
    {
        'website':'58同城',
        'batch':'2017-09-15'
    }
    '''
    today = Time_utils.getNowDate()
    batch_conn = Mongo_utils(db_name, 'batch_info')
    batch_conn.collection.update({'website': website}, {
                                 '$set': {'batch': today}, '$setOnInsert': {'website': website}}, upsert=True)


class CompressData(object):
    def __init__(self, data):
        self.data = data

    def compress(self):
        return zlib.compress(self.data)

    def decompress(self):
        return zlib.decompress(self.data)


if __name__ == '__main__':
    print Mongo_utils('test', 'c').insert_data({'x': 1})
    print '------------'
    print Mongo_utils('test', 'c').insert_data([{'x': 1, 'y': 2, 'z': 3}])
