# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


import pymongo
import redis
from settings import MONGO_CONF, PRJ_DEBUG, STORAGE_SETTINGS
from utils import get_batch


class MongoPipeline(object):
    def __init__(self):
        self.host = MONGO_CONF['host']
        self.port = MONGO_CONF['port']
        if not PRJ_DEBUG:
            self.user = MONGO_CONF['user']
            self.passwd = MONGO_CONF['passwd']

    def open_spider(self, spider):
        spider_name = spider.name
        if spider_name in STORAGE_SETTINGS:
            db_name = STORAGE_SETTINGS[spider_name].get('db')
            self.client = pymongo.MongoClient(host=self.host, port=self.port)
            self.db = self.client[db_name]
            website = STORAGE_SETTINGS[spider_name].get('website')
            self.batch = get_batch(website, db_name)
            if not PRJ_DEBUG:
                self.db.authenticate(self.user, self.passwd, source='admin')

    def process_item(self, item, spider):
        spider_name = spider.name
        if spider_name in STORAGE_SETTINGS:
            collection_name = STORAGE_SETTINGS[spider_name].get('collection')
            collection_name = '_'.join([collection_name, self.batch])
            data = item.get('data')
            if isinstance(data, dict):
                self.db[collection_name].insert(dict(data))
            elif isinstance(data, list):
                self.db[collection_name].insert_many(list(data))
            else:
                pass
        return item

    def close_spider(self, spider):
        if spider.name in STORAGE_SETTINGS:
            self.client.close()
