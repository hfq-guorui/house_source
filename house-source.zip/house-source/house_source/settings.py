# -*- coding: utf-8 -*-

# Scrapy settings for house_source project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     http://doc.scrapy.org/en/latest/topics/settings.html
#     http://scrapy.readthedocs.org/en/latest/topics/downloader-middleware.html
#     http://scrapy.readthedocs.org/en/latest/topics/spider-middleware.html
import os

PRJ_DEBUG = False

ROOT_URL = os.path.dirname(os.path.abspath('__file__'))

BOT_NAME = 'house_source'

SPIDER_MODULES = ['house_source.spiders']
NEWSPIDER_MODULE = 'house_source.spiders'


# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'house_source (+http://www.yourdomain.com)'

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

# Configure maximum concurrent requests performed by Scrapy (default: 16)
CONCURRENT_REQUESTS = 48

# Configure a delay for requests for the same website (default: 0)
# See http://scrapy.readthedocs.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs

DOWNLOAD_DELAY = 0.2  # 下载延迟2s
# The download delay setting will honor only one of:
#CONCURRENT_REQUESTS_PER_DOMAIN = 16
#CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
#TELNETCONSOLE_ENABLED = False

# Override the default request headers:
# DEFAULT_REQUEST_HEADERS = {
#     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
#     'Accept-Language': 'en',
# }

# Enable or disable spider middlewares
# See http://scrapy.readthedocs.org/en/latest/topics/spider-middleware.html
# SPIDER_MIDDLEWARES = {
#    'house_source.middlewares.MyCustomSpiderMiddleware': 543,
#}
DOWNLOAD_TIMEOUT = 30
# Enable or disable downloader middlewares
# See http://scrapy.readthedocs.org/en/latest/topics/downloader-middleware.html
DOWNLOADER_MIDDLEWARES = {
    # 'house_source.middlewares.MyCustomDownloaderMiddleware': 543,
    'house_source.middlewares.CustomMiddleware': 50,  # 过滤验证码页面
    'house_source.middlewares.RandomUserAgent': 100,  # 随机使用userAgents
    'house_source.middlewares.ProxyMiddleware': 200,  # 使用代理IP
    'scrapy.downloadermiddlewares.retry.RetryMiddleware': 300,
    'house_source.middlewares.CustomRetryMiddleware': 500,
}

# Enable or disable extensions
# See http://scrapy.readthedocs.org/en/latest/topics/extensions.html
MYEXT_ENABLED = True
MYEXT_ITEMCOUNT = 10000
EXTENSIONS = {
    'scrapy.extensions.telnet.TelnetConsole': None,
}

# Configure item pipelines
# See http://scrapy.readthedocs.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
    'house_source.pipelines.MongoPipeline': 100,
}


# Enable and configure the AutoThrottle extension (disabled by default)
# See http://doc.scrapy.org/en/latest/topics/autothrottle.html
#AUTOTHROTTLE_ENABLED = True
# The initial download delay
#AUTOTHROTTLE_START_DELAY = 2
# The maximum download delay to be set in case of high latencies
#AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
#AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
# AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See http://scrapy.readthedocs.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
#HTTPCACHE_ENABLED = True
#HTTPCACHE_EXPIRATION_SECS = 0
#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_IGNORE_HTTP_CODES = []
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 "
    "(KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1",
    "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 "
    "(KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 "
    "(KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 "
    "(KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",
    "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 "
    "(KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 "
    "(KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",
    "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 "
    "(KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 "
    "(KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.24 "
    "(KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
    "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 "
    "(KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24"
]


if PRJ_DEBUG:
    MONGO_CONF = dict(host='192.168.229.133', port=27017, db='houses')
    # MONGO_CONF = dict(host='192.168.222.128', port=27017, db='houses')
    # MONGO_CONF = dict(host='192.168.59.130', port=27017, db='houses')
    # MONGO_CONF2 = dict(host='192.168.59.130', port=27017, db='houses2')
    # MONGO_CONF2 = dict(host='192.168.222.128', port=27017, db='houses2')
    MONGO_CONF2 = dict(host='192.168.229.133', port=27017, db='houses2')
    REDIS_HOST = '127.0.0.1'
    REDIS_PORT = 6379
    REDIS_PASS = None

else:
    # crawler3 db1
    MONGO_CONF = dict(host='10.30.134.215', port=27016, db='houses',
                      user='root', passwd='liujiatian@huizhaofang')
    MONGO_CONF2 = dict(host='10.30.134.215', port=27016, db='houses2',
                       user='root', passwd='liujiatian@huizhaofang')
    REDIS_HOST = '10.30.134.215'
    REDIS_PORT = 18118
    REDIS_PASS = 'liujiatian@huizhaofang'

# 代理重试设置
RETRY_ENABLED = True
RETRY_TIMES = 3
RETRY_HTTP_CODES = [500, 503, 504, 400, 403, 404, 408]


# SCHEDULER = "scrapy_redis.scheduler.Scheduler"
SCHEDULER_PERSIST = True
# 去重
DUPEFILTER_CLASS = "scrapy_redis.dupefilter.RFPDupeFilter"
SCHEDULER_QUEUE_CLASS = 'scrapy_redis.queue.SpiderQueue'
REDIS_START_URLS_AS_SET = True
REDIS_DB = 0
PROXY_DB = 1

STORAGE_SETTINGS = {

    # 大型租房网站

    # 58同城
    'tongcheng58': {'db': 'houses', 'collection': 'tongcheng58_house', 'website': u'58同城房源'},
    'tongcheng58_community': {'db': 'houses', 'collection': 'tongcheng58_community', 'website': u'58同城小区'},
    # 赶集
    'ganji': {'db': 'houses', 'collection': 'ganji_house', 'website': u'赶集房源'},
    'ganji_community': {'db': 'houses', 'collection': 'ganji_community', 'website': u'赶集小区'},
    'ganji_broker': {'db': 'houses', 'collection': 'ganji_broker', 'website': u'赶集经纪人'},
    # 房天下
    'fangtianxia': {'db': 'houses', 'collection': 'fangtianxia_house', 'website': u'房天下房源'},
    'fangtianxia_community': {'db': 'houses', 'collection': 'fangtianxia_community', 'website': u'房天下小区'},
    # 链家
    'lianjia': {'db': 'houses', 'collection': 'lianjia_house', 'website': u'链家房源'},
    'lianjia_community': {'db': 'houses', 'collection': 'lianjia_community', 'website': u'链家小区'},
    'lianjia_broker': {'db': 'houses', 'collection': 'lianjia_broker', 'website': u'链家经纪人'},

    # 集中式公寓

    # 58公寓
    'department58': {'db': 'houses2', 'collection': 'department58_house', 'website': u'58公寓'},

    # 相寓
    'xiangyu': {'db': 'houses2', 'collection': 'xiangyu_house', 'website': u'相寓房源'},

    'xiangyubj': {'db': 'houses2', 'collection': 'xiangyu_house', 'website': u'相寓房源'},
    
    #蛋壳
    'danke': {'db': 'houses2', 'collection': 'danke_house', 'website': u'蛋壳房源'},
    
}
