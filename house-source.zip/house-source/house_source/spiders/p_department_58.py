# -*- coding: utf-8 -*-

import json
from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, CompressData


CITYS = {
    u'北京': 'bj',
    u'上海': 'sh',
    u'杭州': 'hz',
    u'深圳': 'sz',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PDepartment58Spider(RedisSpider):
    name = "p_department58"
    allowed_domains = map(lambda x: x + '.58.com', CITYS.values())
    redis_key = 'p_department58:start_urls'

    def parse(self, response):
        selector = Selector(response)
        domain = response.url[:16]
        urls = selector.xpath('//ul[@class="list"]//a/@href').extract()
        urls = map(lambda x: domain + x, urls)
        for index, url in enumerate(urls):
            allow_short_rent = selector.xpath(
                '//ul[@class="list"]/li[%s]/a/div[@class="des"]/p/b/text()' % str(index + 1)).extract_first()
            rent_monthly = selector.xpath(
                '//ul[@class="list"]/li[%s]/a/div[@class="money"]/p/text()' % str(index + 1)).extract_first()
            small_logo = selector.xpath(
                '//ul[@class="list"]/li[%s]/a/div[@class="small-logo"]' % str(index + 1)).extract_first()
            page_type = 2 if small_logo else 1
            meta_data = json.dumps({'meta': {'allow_short_rent': allow_short_rent,
                                             'rent_monthly': rent_monthly, 'page_type': page_type}})
            meta_data = CompressData(meta_data).compress()
            if Redis_utils.insert_meta('department58:meta', url, meta_data):
                Redis_utils.insert_url('department58:start_urls', url)
        next_url = selector.xpath('//a[@class="next"]/@href').extract_first()
        if next_url:
            next_url = domain + next_url
            yield Request(next_url, callback=self.parse)
