# -*- coding: utf-8 -*-
import re
import json
import scrapy
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData
from bson.objectid import ObjectId

# 郑州和西安没有
CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class LianjiaSpider(RedisSpider):
    name = "lianjia"
    allowed_domains = map(lambda x: x + '.lianjia.com', CITYS.keys())
    redis_key = 'lianjia:start_urls'

    def parse(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        content = response.body_as_unicode()
        response_url = response.url
        try:
            meta_data = Redis_utils.get_meta('lianjia:meta', response_url)
            meta_data = json.loads(CompressData(meta_data).decompress())
            people_count = meta_data.get('meta').get('people_count')
            complete_time = meta_data.get('meta').get('complete_time')
            update_time = meta_data.get('meta').get('update_time')
            brand = meta_data.get('meta').get('brand')
            p_monitor_id = ObjectId(meta_data.get('meta').get('_id'))
        except:
            people_count = None
            complete_time = None
            update_time = None
            brand = u'链家'
            p_monitor_id = None
        if brand == u'自如':
            # 方式-租金-押金-服务费
            fs_zj_yj_fwf = []
            # 方式的数量
            pay_count = len(selector.xpath(
                '//div[@id="pay"]/ul/li[position()>1]'))
            for i in range(pay_count):
                fs = selector.xpath(
                    '//div[@id="pay"]/ul/li[%s]/span[1]/b/text()' % str(i + 2)).extract_first()
                zj = selector.xpath(
                    '//div[@id="pay"]/ul/li[%s]/span[2]/text()' % str(i + 2)).extract_first()
                yj = selector.xpath(
                    '//div[@id="pay"]/ul/li[%s]/span[3]/text()' % str(i + 2)).extract_first()
                fwf = selector.xpath(
                    '//div[@id="pay"]/ul/li[%s]/span[4]/text()' % str(i + 2)).extract_first()
                fs_zj_yj_fwf.append([fs, zj, yj, fwf])
        else:
            fs_zj_yj_fwf = None
        house_id = response_url.split('/')[-1].split('.')[0]
        house_name = selector.xpath(
            '//h1[@class="main"]/text()').extract_first()
        city = selector.xpath(
            '/html/body/div[3]/div/div/a[2]/text()').extract_first()[:-2]
        district = selector.xpath(
            '/html/body/div[3]/div/div/a[3]/text()').extract_first()[:-2]
        zone = selector.xpath(
            '/html/body/div[3]/div/div/a[4]/text()').extract_first()[:-2]
        price = selector.xpath('//span[@class="total"]/text()').extract_first()
        decoration = selector.xpath(
            '//span[@class="tips decoration"]/text()').extract_first()
        area = selector.xpath(
            '//div[@class="content zf-content"]/div[@class="zf-room"]/p[1]/text()').extract_first()
        house_type = selector.xpath(
            '//div[@class="content zf-content"]/div[@class="zf-room"]/p[2]/text()').extract_first()
        house_floor = selector.xpath(
            '//div[@class="content zf-content"]/div[@class="zf-room"]/p[3]/text()').extract_first()
        house_direction = selector.xpath(
            '//div[@class="content zf-content"]/div[@class="zf-room"]/p[4]/text()').extract_first()
        traffic = selector.xpath(
            '//div[@class="content zf-content"]/div[@class="zf-room"]/p[5]/text()').extract_first()
        community_url = selector.xpath(
            '/html/body/div[4]/div[2]/div[2]/div[2]/p[6]/a[1]/@href').extract_first()
        community_id = community_url.split('/')[-2] if community_url else None
        community_name = selector.xpath(
            '//div[@class="content zf-content"]/div[@class="zf-room"]/p[last()-2]/a[1]/text()').extract_first()
        publish_time = selector.xpath(
            '//div[@class="content zf-content"]/div[@class="zf-room"]/p[last()]/text()').extract_first()
        broker = selector.xpath(
            '//div[@class="brokerName"]/a/@href').extract_first()
        broker_id = broker.split('/')[-1].split('.')[0] if broker else None
        broker_name = selector.xpath(
            '//div[@class="brokerName"]/a/text()').extract_first() if broker else None
        phone_num = selector.xpath(
            '//div[@class="brokerInfoText"]/div[@class="phone"]/text()').extract()
        if phone_num:
            num = map(lambda x: re.sub(' |\n', '', x), phone_num)
            phone_num = u'转'.join(num)
        title = selector.xpath(
            '//div[@class="content"]/ul/li/span/text()').extract()
        title = map(lambda x: x.split(u'：')[0], title)
        content = []
        count = selector.xpath(
            '//div[@class="base"]/div[2]/ul/li/text()').extract()
        for i in count:
            if i.strip():
                content.append(i.strip())
        base_info = zip(title, content)
        image_urls = selector.xpath(
            '//div[@class="thumbnail"]/ul/li/img/@src').extract()
        image_title = selector.xpath(
            '//div[@class="thumbnail"]/ul/li/@data-desc').extract()
        image_urls_dict = zip(image_urls, image_title)
        facilities = selector.xpath(
            '//ul[@class="se"]/li[contains(@class,"tags")]/text()[2]').extract()
        if facilities:
            facilities = map(lambda x: x.strip(), facilities)
        data = dict(
            people_count=people_count,
            complete_time=complete_time,
            update_time=update_time,
            house_id=house_id,
            house_name=house_name,
            city=city,
            district=district,
            zone=zone,
            price=price,
            decoration=decoration,
            area=area,
            house_type=house_type,
            house_floor=house_floor,
            house_direction=house_direction,
            traffic=traffic,
            community_id=community_id,
            community_name=community_name,
            publish_time=publish_time,
            broker_id=broker_id,
            broker_name=broker_name,
            phone_num=phone_num,
            base_info=base_info,
            brand=brand,
            url=response_url,
            fs_zj_yj_fwf=fs_zj_yj_fwf,
            image_urls=image_urls_dict,
            facilities=facilities,
            crawl_time=Time_utils.getNowTime(),
            p_monitor_id=p_monitor_id
        )
        item['data'] = data
        yield item
