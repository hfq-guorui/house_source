# -*- coding: utf-8 -*-

import json
from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy import Selector
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, CompressData


CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PGanjiSpider(RedisSpider):
    name = "p_ganji"
    redis_key = 'p_ganji:start_urls'
    allowed_domains = map(lambda x: x + '.ganji.com', CITYS.values())

    def parse(self, response):
        selector = Selector(response)
        domain = response.url[:19]
        rent_type_urls = selector.xpath(
            '//div[@class="f-f-content"]/dl[2]/dd/a/@href').extract()
        for i in range(2):
            next_url = domain + rent_type_urls[i + 1]
            rent_type = u'整租' if i == 0 else u'合租'
            yield Request(next_url, meta={'domain': domain, 'rent_type': rent_type}, callback=self.parse_price, dont_filter=True)

    def parse_price(self, response):
        domain = response.meta.get('domain')
        selector = Selector(response)
        price_range = selector.xpath(
            '//div[@class="f-f-content"]/dl[3]/dd/a[position()>1]/@href').extract()
        urls = map(lambda x: domain + x, price_range)
        for url in urls:
            yield Request(url, meta=response.meta, callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        rent_type = response.meta.get('rent_type')
        meta_data = json.dumps(
            {'meta': {'rent_type': rent_type, 'domain': domain}})
        meta_data = CompressData(meta_data).compress()
        house_urls = selector.xpath(
            '//div[@class="f-list js-tips-list"]//dd[@class="dd-item title"]/a/@href').extract()
        house_urls = map(lambda x: domain + x, house_urls)
        for url in house_urls:
            if url.find('?') == -1:
                if Redis_utils.insert_meta('ganji:meta', url, meta_data):
                    Redis_utils.insert_url('ganji:start_urls', url)
            else:
                if Redis_utils.insert_meta('ganji:meta', url[:url.find('?')], meta_data):
                    Redis_utils.insert_url(
                        'ganji:start_urls', url[:url.find('?')])

        if int(selector.xpath(u'//ul[@class="pageLink clearfix"]/li[last()]/a/span/text()="下一页 >"').extract_first()):
            next_url = domain + \
                selector.xpath(
                    '//ul[@class="pageLink clearfix"]/li[last()]/a/@href').extract_first()
            yield Request(next_url, meta={'domain': domain, 'rent_type': rent_type}, callback=self.parse_list)
