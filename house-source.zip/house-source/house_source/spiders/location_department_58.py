# -*- coding: utf-8 -*-

import scrapy
from scrapy import Request, Selector
from house_source.utils import Redis_utils

CITYS = {
    'bj': u'北京',
    'sh': u'上海',
    'hz': u'杭州',
    'sz': u'深圳',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class LocationDepartment58Spider(scrapy.Spider):
    name = "location_department58"
    allowed_domains = map(lambda x: x + '.58.com', CITYS.keys())

    def __init__(self, city):
        self.city = city
        for city_prefix, city_name in CITYS.iteritems():
            if city_name == self.city:
                self.start_urls = [
                    'http://{}.58.com/pinpaigongyu/'.format(city_prefix)]

    def parse(self, response):
        selector = Selector(response)
        domain = response.url[:-14]
        district_urls = selector.xpath(
            '//div[@class="selectBar select-item"]//div[@class="wz-mod2 mod2-qy"]/a[position()>1]/@href').extract()
        for url in district_urls:
            yield Request(domain + url, meta={'domain': domain}, callback=self.parse_zones, dont_filter=True)

    def parse_zones(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        zones_urls = selector.xpath(
            '//div[@class="selectBar select-item"]//div[@class="wz-mod3 mod3-qy"]/p/a/@href').extract()
        if not zones_urls:
            Redis_utils.insert_url('p_department58:start_urls', response.url)
        else:
            zones_urls = map(lambda x: domain + x, zones_urls)
            Redis_utils.insert_url('p_department58:start_urls', zones_urls)
