# -*- coding: utf-8 -*-

import math
from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PLianjiaBrokerSpider(RedisSpider):
    name = "p_lianjia_broker"
    headers = {
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.8"
    }
    redis_key = 'p_lianjia_broker:start_urls'

    def parse(self, response):
        selector = Selector(response)
        current_url = response.url
        broker_count = int(selector.xpath(
            '/html/body/div[4]/div[2]/div/div[1]/h2/span/text()').extract_first())
        page = int(math.ceil(broker_count / 30.0))
        for i in range(page):
            yield Request(current_url + 'pg%s/' % str(i + 1), headers=self.headers, callback=self.parse_broker_list, dont_filter=True)

    def parse_broker_list(self, response):
        selector = Selector(response)
        urls = selector.xpath(
            '//ul[@class="agent-lst"]/li/div[2]/div[1]/a[1]/@href').extract()
        urls = map(lambda x: x + '/', urls)
        for url in urls:
            Redis_utils.insert_url('lianjia_broker:start_urls', url)
