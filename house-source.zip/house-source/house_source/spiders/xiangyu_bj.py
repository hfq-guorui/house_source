#-*- coding:utf8 -*-
__author__ = 'GuoRui'

import re
import json

from scrapy import Spider
from scrapy import Selector
from scrapy import FormRequest
from scrapy import Request

from house_source.utils import Time_utils
from house_source.items import HouseSourceItem

CITY_DICT = {"bj":u"北京"}

DETAIL_EXTRACT_DICT = {
    "price":"//p[@class='lef']/span[1]/text()",
    "rent_type":"//ul[@class='hos-basic-info'][1]/li[@class='inf clearfix'][1]/p[@class='rg']/span/text()",
    "house_type":"//ul[@class='hos-basic-info'][1]/li[@class='inf clearfix'][2]/p[@class='rg']/span/text()",
    "floor_type":"//ul[@class='hos-basic-info'][1]/li[@class='inf clearfix'][3]/p[@class='rg']/span/text()",
    "area":"//ul[@class='hos-basic-info'][1]/li[@class='inf clearfix'][4]/p[@class='rg']/span/text()",
    "house_direction":"//ul[@class='hos-basic-info'][1]/li[@class='inf clearfix'][4]/p[@class='rg']/span/text()",
    "complete_time":"//ul[@class='hos-basic-info'][2]/li[@class='inf clearfix'][1]/p[@class='rg']/span/text()",
    "building_type":"//ul[@class='hos-basic-info'][2]/li[@class='inf clearfix'][2]/p[@class='rg']/span/text()",
    "community_name":"//div[@class='address']/span[2]/text()",
    "house_id":"//p[@class='house-number']/span/text()",
    "imgurl":"//ul[@class='slider-img swiper-wrapper']/li/img/@src",
}

class XiangyuBj(Spider):
    name = "xiangyubj"
    allowed_domains = ["ali.1zu.com"]
    start_urls = ["https://ali.1zu.com/house/list.htm"]

    def parse(self,response):
        body = response.body
        meta = response.meta

        city = CITY_DICT.values()[0]

        match_circle_dict = re.search(r"circleList = '(.*?)';",body)
        if match_circle_dict:
            circle_dict_str = match_circle_dict.group(1)
            circle_dict = json.loads(circle_dict_str)
            if isinstance(circle_dict,dict) and len(circle_dict):
                district_childs = circle_dict["children"]
                for district_child_dict in district_childs:
                    one_district_child_id = district_child_dict["id"]
                    district_name = district_child_dict['text']
                    zone_childs = district_child_dict["children"]
                    for one_zone_dict in zone_childs:
                        zone_id = one_zone_dict['id']
                        zone_name = one_zone_dict['text']
                        post_url = "https://ali.1zu.com/house/get_listByPage.htm"
                        meta['city'] = city
                        meta["district_name"] = district_name
                        meta["zone_name"] = zone_name
                        post_data = {
                            "pageNum":"0",
                            "rentType":"",
                            "inDistrict":one_district_child_id,
                            "businessCircleId":zone_id,
                            "priceType":"0",
                            "houseType":"",
                            "orderByType":"",
                            "minPrice":"",
                            "maxPrice":"",
                        }
                        headers = {
                            "Connection": "keep-alive",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                        }
                        meta["post_data"] = post_data
                        meta["post_url"] = post_url
                        meta["headers"] = headers
                        yield FormRequest(url=post_url,headers=headers,formdata=post_data,callback=self.parse_detail_url,meta=meta,dont_filter=True)

    def parse_detail_url(self,response):
        body = response.body
        meta = response.meta
        post_data = meta["post_data"]

        houses_dict = json.loads(body)
        headers = {
            "Connection": "keep-alive",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        }
        if houses_dict["houseList"] != []:
            post_url = meta["post_url"]
            page_num = post_data["pageNum"]
            new_page_num = str(int(page_num) + 1)
            post_data["pageNum"] = new_page_num
            yield FormRequest(url=post_url,formdata=post_data,callback=self.parse_detail_url,meta=meta,dont_filter=True,headers=headers)
            houses_list = houses_dict["houseList"]
            for one_house_info_dict in houses_list:
                houses_id = one_house_info_dict["houseId"]
                rent_type = one_house_info_dict["rentType"]
                room_id = one_house_info_dict["roomsID"]
                one_house_url = "https://ali.1zu.com/house/detail{}.htm?roomId={}&rentType={}".format(houses_id,room_id,rent_type)
                yield Request(one_house_url,callback=self.parse_detail,meta=meta,dont_filter=True)

    def parse_detail(self,response):
        body = response.body
        url = response.url
        meta = response.meta

        city = meta["city"]
        district = meta["district_name"]
        zone = meta["zone_name"]
        sel = Selector(text=body)
        result_dict = {}
        for one_key in DETAIL_EXTRACT_DICT:
            extract_method = DETAIL_EXTRACT_DICT[one_key]
            extract_list = sel.xpath(extract_method).extract()
            if one_key != "imgurl":
                if isinstance(extract_list,list) and len(extract_list):
                    result_dict[one_key] = extract_list[0].strip()
                else:
                    result_dict[one_key] = ""
            else:
                result_dict[one_key] = extract_list

        item = HouseSourceItem()

        data = dict(
                    house_id=result_dict["house_id"],
                    community_name=result_dict["community_name"],
                    price=result_dict["price"],
                    house_type=result_dict["house_type"],
                    rent_type=result_dict["rent_type"],
                    floor_type=result_dict["floor_type"],
                    area=result_dict["area"],
                    house_direction=result_dict["house_direction"],
                    complete_time=result_dict["complete_time"],
                    building_type=result_dict["building_type"],
                    city=city,
                    district=district,
                    zone=zone,
                    imgurl=result_dict["imgurl"],
                    url=url,
                    )
        item['data'] = data
        yield item

