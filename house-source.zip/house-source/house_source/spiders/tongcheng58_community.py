# -*- coding: utf-8 -*-

import json
import re
from scrapy import Request, Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData

CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class Parse_detail(object):

    @classmethod
    def get_location(cls, content):
        selector = Selector(text=content)
        locations = selector.xpath(
            '//div[@class="nav"]/a/text()').extract()
        if len(locations)==4:
            city = locations[2][:-2]
            district = None
            zone = None
        elif len(locations)==5:
            city = locations[2][:-2]
            district = locations[3][:-2]
            zone = None
        elif len(locations)==6:
            city = locations[2][:-2]
            district = locations[3][:-2]
            zone = locations[4][:-2]
        else:
            city = None
            district = None
            zone = None
        return city, district, zone

    @classmethod
    def get_coordinate(cls, content):
        try:
            longitude = re.search('lon:\'(\d+.\d+)\'', content).group(1)
            latitude = re.search('lat:\'(\d+.\d+)\'', content).group(1)
        except:
            longitude = None
            latitude = None
        return longitude, latitude


class Tongcheng58CommunitySpider(RedisSpider):
    name = 'tongcheng58_community'
    redis_key = 'tongcheng58_community:start_urls'

    def __init__(self, *args, **kwargs):
        super(Tongcheng58CommunitySpider, self).__init__(*args, **kwargs)
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))

    def parse(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        content = response.body_as_unicode()
        try:
            meta_data = Redis_utils.get_meta(
                'tongcheng58_community:meta', response.url)
            meta_data = CompressData(meta_data).decompress()
            community_id = json.loads(meta_data).get(
                'meta').get('community_id')
            sale_count = json.loads(meta_data).get('meta').get('sale_count')
            rent_count = json.loads(meta_data).get('meta').get('rent_count')
        except:
            community_id = None
            sale_count = None
            rent_count = None
        city, district, zone = Parse_detail.get_location(content)
        community_name = selector.xpath('//h1/text()').extract_first()
        alias = selector.xpath('//h1/span/text()').extract_first()
        price = selector.xpath(
            '//span[@class="moneyColor"]/text()').extract_first()
        address = selector.xpath(
            '//dl[@class="bhrInfo"]/dd[3]/span[@class="ddinfo"]/text()').extract_first()
        if address:
            address = address.strip()
        post_code = selector.xpath(
            '//dl[@class="bhrInfo"]/dd[4]/text()').extract_first()
        building_info = selector.xpath(
            '//dl[@class="bhrInfo"]/dd[5]/text()').extract()
        if len(building_info) == 2:
            complete_time = building_info[0].strip()
            building_type = building_info[1].strip()
        property_company = selector.xpath(
            '//dl[@class="bhrInfo"]/dd[6]/text()').extract_first()
        if property_company:
            property_company = property_company.strip()
        property_fee = selector.xpath(
            '//dl[@class="bhrInfo"]/dd[7]/span[@class="ddinfo"]/text()').extract_first()
        if property_fee:
            property_fee = property_fee.strip()
        developers = selector.xpath(
            '//dl[@class="bhrInfo"]/dd[8]/text()').extract_first()
        if developers:
            developers = developers.strip()
        plot_ratio = selector.xpath(
            '//div[@id="peitao_3"]/ul/li[1]/span[@class="liinfo"]/text()').extract_first()
        if plot_ratio:
            plot_ratio = plot_ratio.strip()
        geen_rate = selector.xpath(
            '//div[@id="peitao_3"]/ul/li[2]/span[@class="liinfo"]/text()').extract_first()
        if geen_rate:
            geen_rate = geen_rate.strip()
        floor_area = selector.xpath(
            '//div[@id="peitao_3"]/ul/li[3]/span[@class="liinfo"]/text()').extract_first()
        if floor_area:
            floor_area = floor_area.strip()
        building_area = selector.xpath(
            '//div[@id="peitao_3"]/ul/li[4]/span[@class="liinfo"]/text()').extract_first()
        if building_area:
            building_area = building_area.strip()
        park_info = selector.xpath(
            '//div[@id="peitao_3"]/ul/li[5]/span[@class="liinfo"]/text()').extract_first()
        if park_info:
            park_info = park_info.strip()
        longitude, latitude = Parse_detail.get_coordinate(content)
        data = dict(
            community_id=community_id,
            sale_count=sale_count,
            rent_count=rent_count,
            city=city,
            district=district,
            zone=zone,
            community_name=community_name,
            alias=alias,
            price=price,
            address=address,
            post_code=post_code,
            complete_time=complete_time,
            building_type=building_type,
            property_company=property_company,
            property_fee=property_fee,
            developers=developers,
            plot_ratio=plot_ratio,
            geen_rate=geen_rate,
            floor_area=floor_area,
            building_area=building_area,
            park_info=park_info,
            longitude=longitude,
            latitude=latitude,
            crawl_time=Time_utils.getNowTime(),
            url=response.url
        )
        item['data'] = data
        yield item
