# -*- coding: utf-8 -*-

import scrapy
import re
from scrapy import Request, Selector
from house_source.items import HouseSourceItem
from house_source.utils import Time_utils

CITYS = {
    'bj':u'北京' ,
    'sh':u'上海' ,
    'sz':u'深圳' ,
    'hz':u'杭州' ,    
}

class Parse_special(object):
    @classmethod
    def get_xpath(cls, response, xpath):
        '''
        获取xpath结果
        '''
        selector = Selector(response)
        name = selector.xpath(xpath).extract()
        return name if name else []

    @classmethod
    def get_house_info(cls, response):
        selector = Selector(response)
        house_infos = selector.xpath('//div[@class="r_lbx_cen"]/div[2]/text()[1]').extract()
        if house_infos:
            house_infos = map(lambda x:re.sub(r'\s+', '', x), house_infos)
        else:
            house_infos = []
        return house_infos

    @classmethod
    def get_price(cls, response):
        selector = Selector(response)
        price_list = selector.xpath('//div[@class="r_lbx_moneya"]//span[position()<last()]/text()').extract()
        if price_list:
            price = ''.join(price_list)
        else:
            price = None
        return price

    @classmethod
    def get_paymethod(cls, response):
        selector = Selector(response)
        length = len(selector.xpath('//div[@class="paymethod"]/table/tr').extract())
        paymethod = []
        if length:
            for i in range(length-1):
                pay_list = selector.xpath('//div[@class="paymethod"]/table/tr[%s]/td/text()' % str(i+2)).extract()
                paymethod.append(pay_list)
        return paymethod

    @classmethod
    def remove_space_str(cls, response, xpath):
        selector = Selector(response)
        name = selector.xpath(xpath).extract_first()
        name = re.sub(r'\s+', '', name)
        return name 

    @classmethod
    def get_site(cls, response):
        selector= Selector(response)
        site = selector.xpath('//div[@class="near_m_img"]/a/img/@src').extract_first()
        site1 = site.split('center=')[-1].split('&markers')[0]
        longitude = site1.split(',')[0]
        latitude = site1.split(',')[-1]
        return longitude, latitude

    @classmethod
    def get_message(cls, response):
        selector = Selector(response)
        length = len(selector.xpath('//div[@class="room_center"]/table/tbody/tr').extract())
        house_message = []
        if length:
            for i in range(length):
                room = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td//text()[1]' % str(i+1)).extract()
                room = map(lambda x:re.sub(r'\s+', '', x), room)
                room = ''.join(room)
                roomie = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[2]/text()' % str(i+1)).extract_first()
                roomie = re.sub(r'\s+', '', roomie)
                if not len(roomie):
                    roomie = '无'
                area = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[3]//text()' % str(i+1)).extract_first()
                area = re.sub(r'\s+', '', area)
                wc = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[4]/i' % str(i+1)).extract_first()
                if 'text_mute' in wc:
                    wc = u'有独卫'
                else:
                    wc = u'无独卫'
                shower = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[5]/i' % str(i+1)).extract_first()
                if 'text_mute' in shower:
                    shower = u'有淋浴'
                else:
                    shower = u'无淋浴'
                balcony = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[6]/i' % str(i+1)).extract_first()
                if 'text_mute' in balcony:
                    balcony = u'有阳台'
                else:
                    balcony = u'无阳台'
                rent = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[7]/text()' % str(i+1)).extract_first()
                rent = re.sub(r'\s+', '', rent)
                if length == 9:
                    charge = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[8]/text()' % str(i+1)).extract_first()
                    charge = re.sub(r'\s+', '', charge)
                    maintenance = selector.xpath('//div[@class="room_center"]/table/tbody/tr[%s]/td[9]/text()' % str(i+1)).extract_first()
                    maintenance = re.sub(r'\s+', '', maintenance)
                    house_message.append([room, roomie, area, wc, shower, balcony, rent, charge, maintenance])
                else:
                    house_message.append([room, roomie, area, wc, shower, balcony, rent])
        return house_message
        
class DankeSpider(scrapy.Spider):
    name = "danke"
    allowed_domains = ["dankegongyu.com"]
    start_urls = map(lambda x:'http://www.dankegongyu.com/room/' + x, CITYS.keys())
    def parse(self, response):
        selector = Selector(response)
        brand_urls = selector.xpath(
            '//div[@class="filter_options"]/dl[1]/dd/div[@class="option_list"]/a[position()>1]/@href').extract()
        for url in brand_urls:
            yield Request(url, callback=self.parse_type)

    def parse_type(self, response):
        selector = Selector(response)
        type_urls = selector.xpath(
            '//div[@class="filter_options"]/dl[2]/dd/div[@class="option_list"]/a[position()>1]/@href').extract()
        for url in type_urls:
            yield Request(url, callback=self.parse_district)

    def parse_district(self, response):
        selector = Selector(response)
        district_urls = selector.xpath(
            '//div[@class="filter_options"]/dl[3]/dd/div[@class="option_list"]/a[position()>1]/@href').extract()
        for url in district_urls:
            yield Request(url, callback=self.parse_zones)

    def parse_zones(self, response):
        selector = Selector(response)
        zones_urls = selector.xpath(
            '//div[@class="filter_options"]/dl[3]/dd/div[@class="sub_option_list"]/a[position()>1]/@href').extract()
        for url in zones_urls:
            yield Request(url, callback=self.parse_list)

    def parse_list(self, response):
        selector = Selector(response)
        brand = selector.xpath('//div[@class="filter_options"]/dl[1]/dd/div[@class="option_list"]/a[@class="onlist"]/text()').extract_first()
        house_type = selector.xpath('//div[@class="filter_options"]/dl[2]/dd/div[@class="option_list"]/a[@class="onlist"]/text()').extract_first()
        district = selector.xpath('//div[@class="filter_options"]/dl[3]/dd/div[@class="option_list"]/a[@class="onlist"]/text()').extract_first()
        zone = selector.xpath('//div[@class="filter_options"]/dl[3]/dd/div[@class="sub_option_list"]/a[@class="on"]/text()').extract_first()
        url_list = Parse_special.get_xpath(response,
            '//div[@class="r_ls_box"]/div/div[1]/a/@href')
        house_info_list = Parse_special.get_house_info(response)
        info_list = zip(url_list, house_info_list)
        for i in info_list:
            url = i[0]
            house_info = i[1]
            yield Request(url, meta={'brand':brand, 'house_type':house_type, 'district':district, 'zone':zone, 'house_info':house_info}, callback=self.parse_detail)

        next_pages_text = selector.xpath('//div[@class="page"]/a[position()=last()]/text()').extract_first() 
        next_pages_url = selector.xpath('//div[@class="page"]/a[position()=last()]/@href').extract_first()
        if next_pages_text == u' > ':
            yield Request(next_pages_url,callback=self.parse_list)

    def parse_detail(self, response):
        selector = Selector(response)
        item = HouseSourceItem()
        brand = response.meta.get('brand')
        house_type = response.meta.get('house_type')
        district = response.meta.get('district')
        zone = response.meta.get('zone')
        house_info = response.meta.get('house_info')
        url = response.url
        house_id = url.split('/')[-1].split('.')[0]
        house_name = Parse_special.remove_space_str(response, '//div[@class="room_detail_gs fr"]/h1/text()')
        price = Parse_special.get_price(response)
        img_url_list = selector.xpath('//div[@class="carousel-inner"]/div/img/@src').extract()
        traffic = Parse_special.remove_space_str(response, '//div[@class="room_de_a"]/text()')
        house_num = selector.xpath('//div[@class="room_detail_q"]/div[1]/text()').extract_first()
        situation = Parse_special.remove_space_str(response, '//div[@class="room_detail_q"]/div[2]/text()')
        pay_way = selector.xpath('//div[@class="ro_de_qatxt"]/a/text()').extract_first()
        phone = Parse_special.remove_space_str(response, '//div[@class="phoneb"]/text()')
        house_tag = selector.xpath('//div[@class="room_detail_q"]/div[5]/span/text()').extract()
        paymethod = Parse_special.get_paymethod(response)
        longitude, latitude = Parse_special.get_site(response)
        house_message = Parse_special.get_message(response)
        data_house = dict(
            brand=brand,
            house_type=house_type,
            district=district,
            zone=zone,
            house_info=house_info,
            url=url,
            house_id=house_id,
            house_name=house_name,
            price=price,
            img_url_list=img_url_list,
            traffic=traffic,
            house_num=house_num,
            situation=situation,
            pay_way=pay_way,
            phone=phone,
            house_tag=house_tag,
            paymethod=paymethod,
            longitude=longitude,
            latitude=latitude,
            house_message=house_message,
            crawl_time=Time_utils.getNowTime(),
        )
        item['data'] = data_house
        yield item