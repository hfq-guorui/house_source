# -*- coding: utf-8 -*-

import json
import scrapy
from scrapy_redis.spiders import RedisSpider
import re
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, CompressData


CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xian',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wuhan',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nanjing',
}


def get_start_urls():
    start_urls = map(lambda x: 'http://zu.' + x + '.fang.com/', CITYS.values())
    start_urls.remove('http://zu.bj.fang.com/')
    start_urls.insert(0, 'http://zu.fang.com/default.aspx')
    return start_urls


class PFangtianxiaSpider(RedisSpider):
    name = "p_fangtianxia"
    allowed_domains = ["fang.com"]
    redis_key = 'p_fangtianxia:start_urls'

    def parse(self, response):
        url = response.url
        selector = Selector(response)
        domain = re.sub(r'com.+','com',url)
        rent_type_urls = response.xpath(
            '//div[@class="search-listbox"]/dl[4]/dd/a/@href').extract()[1:3]
        rent_type_urls = map(lambda x: domain + x, rent_type_urls)
        for url in rent_type_urls:
            rent_type = u'整租' if url.endswith('/n31/') else u'合租'
            yield Request(url, meta={'domain': domain, 'rent_type': rent_type}, callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):
        selector = Selector(response)
        rent_type = response.meta.get('rent_type')
        domain = response.meta.get('domain')
        meta_data = json.dumps(
            {'meta': {'rent_type': rent_type}})
        meta_data = CompressData(meta_data).compress()
        urls = selector.xpath(
            '//p[@class="title"]/a/@href').extract()
        for url in urls:
            if url.startswith('/chuzu/'):
                complete_url = domain + url
                if Redis_utils.insert_meta('fangtianxia:meta', complete_url, meta_data):
                    Redis_utils.insert_url(
                        'fangtianxia:start_urls', complete_url)
        if int(selector.xpath(u'//div[@class="fanye"]/a/text()="下一页"').extract_first()):
            next_page_url = domain + selector.xpath(
                '//div[@class="fanye"]/a[last()-1]/@href').extract_first()
            yield Request(next_page_url, meta={'rent_type': rent_type, 'domain': domain}, callback=self.parse_list)
