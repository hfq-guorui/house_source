# -*- coding: utf-8 -*-

import re
import json
from scrapy import Request
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils

CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class Parse_Special(object):
    @classmethod
    def get_image_urls(cls, content):
        selector = Selector(text=content)
        image_urls = []
        try:
            prefix = selector.xpath(
                '//div[@class="basic-box clearfix"]/div/div/@data-url').extract_first()
            suffix = json.loads(selector.xpath(
                '//div[@class="basic-box clearfix"]/div/div/@data-imgs').extract_first())
            big_images = suffix.get('bImgs', [])
            for i in big_images:
                temp_list = ''.join(i.split('\\'))
                temp_list = prefix + temp_list
                image_urls.append(temp_list)
            return image_urls
        except:
            return []

    @classmethod
    def get_coordinate(cls, content):
        try:
            parsed_content = re.findall(
                "lnglat\":\"b((\d+.\d+),(\d+.\d+))", content)[0]
            longitude, latitude = parsed_content[1], parsed_content[2]
        except:
            longitude = None
            latitude = None
        return longitude, latitude


class GanjiCommunitySpider(RedisSpider):
    name = "ganji_community"
    allowed_domains = map(
        lambda x: '{}.ganji.com/xiaoqu/'.format(x), CITYS.keys())
    redis_key = 'ganji_community:start_urls'

    def parse(self, response):
        selector = Selector(response)
        content = response.body_as_unicode()
        item = HouseSourceItem()
        current_url = response.url
        community_id = current_url.split('/')[-2]
        community_name = selector.xpath(
            '//h1[@class="xiaoqu-title"]/text()').extract_first()
        image_urls = Parse_Special.get_image_urls(content)
        city = selector.xpath(
            '//div[@class="crumbs clearfix"]/a[2]/text()').extract_first()[:-2]
        district = selector.xpath(
            '//div[@class="crumbs clearfix"]/a[3]/text()').extract_first()[:-2]
        zone = selector.xpath(
            '//div[@class="crumbs clearfix"]/a[4]/text()').extract_first()
        if zone:
            zone = zone[:-2]
        community_price = selector.xpath(
            '//b[@class="basic-info-price"]/text()').extract_first()
        second_hand_count = selector.xpath(
            '//span[@class="fl w-100"]/a/text()').extract_first()
        rent_house_count = selector.xpath(
            '//span[@class="fl w-100"]/a/text()').extract()[-1]
        address = selector.xpath(
            '//span[@class="fl w-295"]/i/text()').extract_first()
        complete_time = selector.xpath(
            '//ul[@class="basic-info-ul"]/li[6]/text()').extract_first()
        # 物业类型
        property_type = selector.xpath(
            '//ul[@class="basic-info-ul"]/li[7]/text()').extract_first()
        developers = selector.xpath(
            '//ul[@class="basic-info-ul"]/li[8]/text()').extract_first()
        property_company = selector.xpath(
            '//ul[@class="basic-info-ul"]/li[9]/text()').extract_first()
        park_count = selector.xpath(
            '//div[@class="xiaoqu-otherinfo"]/dl[1]/dd/text()').extract_first()
        # 容积率
        plot_ratio = selector.xpath(
            '//div[@class="xiaoqu-otherinfo"]/dl[2]/dd[1]/div[1]/text()[2]').extract_first().strip()
        geen_rate = selector.xpath(
            '//div[@class="xiaoqu-otherinfo"]/dl[2]/dd[1]/div[2]/text()[2]').extract_first().strip()
        # 物业费
        property_fee = selector.xpath(
            '//div[@class="xiaoqu-otherinfo"]/dl[2]/dd[2]/div/text()').extract_first()
        community_desc = selector.xpath(
            '//div[@class="xiaoqu-otherinfo"]/dl[4]/dd/@data-toggle-text|//div[@class="xiaoqu-otherinfo"]/dl[4]/dd/span/text()').extract_first()
        longitude, latitude = Parse_Special.get_coordinate(content)
        crawl_time = Time_utils.getNowTime()
        data = dict(
            community_id=community_id,
            community_name=community_name,
            image_urls=image_urls,
            city=city,
            district=district,
            zone=zone,
            community_price=community_price,
            second_hand_count=second_hand_count,
            rent_house_count=rent_house_count,
            address=address,
            complete_time=complete_time,
            property_type=property_type,
            developers=developers,
            property_company=property_company,
            park_count=park_count,
            plot_ratio=plot_ratio,
            geen_rate=geen_rate,
            property_fee=property_fee,
            community_desc=community_desc,
            longitude=longitude,
            latitude=latitude,
            crawl_time=crawl_time,
            url=current_url
        )
        item['data'] = data
        yield item
