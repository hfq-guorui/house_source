# -*- coding: utf-8 -*-

import scrapy
import json
from scrapy import Request, Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils
from bson.objectid import ObjectId

class Parse_special(object):
    @classmethod
    def get_pay(cls,response):
        selector = Selector(response)   
        try:
            pay_type = selector.xpath('//ul[@class="houseInfo-meta bbOnepx"]/li[2]/span[@class="pay"]/text()').extract_first().strip()
        except:
            pay_type = None
        return pay_type
    @classmethod
    def get_floor(cls,response):
        selector = Selector(response)
        try:
            house_floor = selector.xpath('//ul[@class="houseInfo-meta bbOnepx"]//li[1]/span[2]/text()').extract_first()
        except:
            house_floor = None
        return house_floor
    @classmethod
    def get_price(cls,response):
        selector = Selector(response)
        try:
            price = selector.xpath('//ul[@class="houseInfo-detail bbOnepx"]/li[2]/i/text()').extract_first().strip()
        except:
            price = None
        return price
    @classmethod
    def get_community_id(cls,response):
        selector = Selector(response)
        try:
            community_id = selector.xpath('//div[@class="houseMap"]/a/@href').extract_first().split('/')[-1]
        except:
            community_id = None
        return community_id
    @classmethod
    def get_bedroom(cls,response):
        selector = Selector(response)
        try:
            bedroom = selector.xpath('//div[@class="body-content"]/ul[@class="houseInfo-detail bbOnepx"]/li[1]/i/text()').extract_first().strip()
        except:
            bedroom = None
        return bedroom
    @classmethod
    def get_detail_address(cls,response):
        selector = Selector(response)
        try:
            detail_address = selector.xpath('//div[@class="houseMap"]/div[@class="area-addr"]/text()').extract_first()
        except:
            detail_address = None
        return detail_address
    @classmethod
    def get_broker(cls,response):
        selector = Selector(response)
        try:
            person_name = selector.xpath('//ul[@class="person"]/li[@class="person-name"]/text()').extract_first()
            #房源类型
            isBrokers = person_name.split('(')[1].split(')')[0]
            #经纪人名称
            broker_name = person_name.split('(')[0]
        except:
            person_name = None
            isBrokers = None
            broker_name = None
        return(isBrokers,broker_name)
    @classmethod
    def get_jwd(cls,response):
        selector = Selector(response)
        try:
            longitude = selector.xpath('//div[@class="houseMap-thumb"]/img/@data-lon').extract_first()
            latitude = selector.xpath('//div[@class="houseMap-thumb"]/img/@data-lat').extract_first()
        except:
            longitude = None
            latitude = None
        return(longitude,latitude)

    @classmethod
    def get_facilities(cls,response):
        selector = Selector(response)
        try:
            facilities = selector.xpath('//div[@class="body-content"]/ul[@class="houseDetail-fac"]/li/text()').extract()
        except:
            facilities = None
        return facilities
    @classmethod
    def get_phone(cls,response):
        selector = Selector(response)
        try:
            phone = selector.xpath('//div[@class="IconBottom"]/a[@class="LinkPhone"]/@phone').extract_first()
        except:
            phone = None
        return phone
class Tongcheng58appSpider(RedisSpider):

    name = "tongcheng58_app"
    allowed_domains = 'http://m.58.com/'
    redis_key = 'tongcheng58_app:start_urls'

    def parse(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        #网页url
        url = response.url
        #房源ID
        house_id = url.split('/')[-1].split('.')[0]
        #房源名称
        house_name = selector.xpath('//div[@class="meta-tit"]/text()').extract_first()
        try:
            meta_data = json.loads(Redis_utils.get_meta(
                'tongcheng58_app:meta', url))
        except:
            return
        p_monitor_id = ObjectId(meta_data.get('meta').get('_id'))
        #城市
        city = meta_data.get('meta').get('city')
        #行政区
        district = meta_data.get('meta').get('district')
        #商圈
        zone = meta_data.get('meta').get('zone')
        #租赁方式
        rent_type = meta_data.get('meta').get('rent_type')
        #房源图片url
        imgage_urls = selector.xpath('//div[@class="image_area_new"]/ul/li/img/@src').extract()
        #价格
        price = Parse_special.get_price(response)
        #支付方式
        pay_type = Parse_special.get_pay(response)
        #户型
        bedroom = Parse_special.get_bedroom(response)
        #面积
        area = selector.xpath('//ul[@class="houseInfo-meta bbOnepx"]/li[2]/span/text()').extract_first()
        #朝向
        house_direction = selector.xpath('//ul[@class="houseDetail-type"]/li[1]/text()').extract_first()
        #楼层
        house_floor = Parse_special.get_floor(response)
        #装修程度
        decoration = selector.xpath('//ul[@class="houseDetail-type"]/li[2]/text()').extract_first()
        #房屋类型
        house_type = selector.xpath('//ul[@class="houseDetail-type"]/li[3]/text()').extract_first()
        #小区ID
        community_id = Parse_special.get_community_id(response)
        #小区名称
        community = selector.xpath('//ul[@class="houseInfo-meta bbOnepx"]/li[1]/span[1]/text()').extract_first()
        #小区地址
        detail_address = Parse_special.get_detail_address(response)
        #经纬度
        longitude,latitude = Parse_special.get_jwd(response)
        #房屋设施
        facilities = Parse_special.get_facilities(response)
        person_name = selector.xpath('//ul[@class="person"]/li[@class="person-name"]/text()').extract_first()
        #房源类型,经纪人名称
        isBrokers,broker_name = Parse_special.get_broker(response)
        #经纪人手机号
        phone = Parse_special.get_phone(response)
        #抓取时间
        crawl_time = Time_utils.getNowTime()
        data = dict(
            house_id = house_id,
            house_name = house_name,
            city = city,
            district = district,
            zone = zone,
            rent_type = rent_type,
            imgage_urls = imgage_urls,
            price = price,
            pay_type = pay_type,
            bedroom = bedroom,
            area = area,
            house_direction = house_direction,
            house_floor = house_floor,
            decoration = decoration,
            house_type = house_type,
            community_id = community_id,
            community = community,
            detail_address = detail_address,
            longitude = longitude,
            latitude = latitude,
            facilities = facilities,
            isBrokers = isBrokers,
            broker_name = broker_name,
            phone = phone,
            crawl_time = crawl_time,
            url = url,
            p_monitor_id = p_monitor_id
            )
        item['data'] = {'house':data}
        yield item