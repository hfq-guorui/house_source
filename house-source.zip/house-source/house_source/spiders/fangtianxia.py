# -*- coding: utf-8 -*-

import re
import json
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData
from bson.objectid import ObjectId


CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xian': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wuhan': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nanjing': u'南京',
}


def get_allow_domains():
    allowed_domains = map(lambda x: "zu." + x + '.fang.com', CITYS.keys())
    allowed_domains += map(lambda x: "esf." + x + '.fang.com', CITYS.keys())
    allowed_domains.append('zu.fang.com')
    allowed_domains.append("esf.fang.com")
    return allowed_domains


def get_start_urls():
    start_urls = map(lambda x: 'http://zu.' + x + '.fang.com/', CITYS.keys())
    start_urls.remove('http://zu.bj.fang.com/')
    start_urls.insert(0, 'http://zu.fang.com/default.aspx')
    return start_urls


class Parse_special(object):
    @classmethod
    def get_sharingInfo_and_address(cls, flag, content):
        selector = Selector(text=content)
        if flag == u'合':
            sharing_info = selector.xpath(
                '//ul[@class="house-info"]/li[4]/text()').extract()
            sharing_info = ' '.join(map(lambda x: x.strip(), sharing_info))
            address = selector.xpath(
                '//ul[@class="house-info"]/li[5]/text()').extract_first()
        else:
            sharing_info = None
            address = selector.xpath(
                '//ul[@class="house-info"]/li[4]/text()').extract_first()
        return sharing_info, address

    @classmethod
    def get_community_name(cls, content):
        selector = Selector(text=content)
        if len(selector.xpath('//ul[@class="house-info"]/li[3]/a')) == 3:
            community_name = selector.xpath(
                '//ul[@class="house-info"]/li[3]/a[1]/text()').extract_first()
        else:
            community_name = selector.xpath(
                '//ul[@class="house-info"]/li[3]/text()').extract_first().split('[')[0].strip()
        return community_name

    @classmethod
    def get_telephone(cls, content):
        selector = Selector(text=content)
        parse_result = selector.xpath(
            '//div[@class="phonewrap clearfix"]/span[1]/text()').extract()
        if len(parse_result) > 1:
            telephone = u'转'.join(parse_result)
        else:
            telephone = parse_result
            telephone = telephone[0] if telephone else None
        return telephone

    @classmethod
    def get_broker_info(cls, content):
        selector = Selector(text=content)
        broker_name = selector.xpath(
            '//div[@class="phonewrap clearfix"]/span[2]/text()').extract_first()
        next_url = selector.xpath(
            '//div[@class="renzheng clearfix"]/ul/li[1]/p/a/@href').extract_first()
        if next_url:
            is_broker = 1
            broker_id = next_url.split('=')[-1]
            agency_name = selector.xpath(
                '//p[@class="mt15 font14"]/a/text()').extract_first()
        else:
            is_broker = 0
            broker_id = None
            agency_name = None
        return broker_name, is_broker, broker_id, agency_name

    @classmethod
    def get_coordinate(cls, content):
        selector = Selector(text=content)
        text = selector.xpath(
            '//iframe[@id="rentid_208"]/@src').extract_first()
        if text:
            try:
                longitude = re.search(
                    'Baidu_coord_x=(\d+.\d+)', content).group(1)
                latitude = re.search(
                    'Baidu_coord_y=(\d+.\d+)', content).group(1)
            except:
                longitude = None
                latitude = None
        else:
            longitude = None
            latitude = None
        return longitude, latitude

    @classmethod
    def get_facilities(cls, content):
        try:
            parsed_facilities = re.search(
                r"var peitao = '(.*)';", content).group(1).split(',')
        except:
            parsed_facilities = None
        return parsed_facilities


class FangtianxiaSpider(RedisSpider):
    name = "fangtianxia"
    allowed_domains = get_allow_domains()
    redis_key = 'fangtianxia:start_urls'

    def parse(self, response):
        '''
        解析房源详情页
        '''
        item = HouseSourceItem()
        selector = Selector(response)
        current_url = response.url
        content = response.body_as_unicode()
        meta_data = Redis_utils.get_meta('fangtianxia:meta', current_url)
        meta_data = json.loads(CompressData(meta_data).decompress())
        p_monitor_id = ObjectId(meta_data.get('meta').get('_id'))
        city = selector.xpath(
            '//div[@class="guide rel"]/a[2]/text()').extract_first().strip()[:-2]
        district = selector.xpath(
            '//div[@class="guide rel"]/a[3]/text()').extract_first().strip()[:-2]
        zone = selector.xpath(
            '//div[@class="guide rel"]/a[4]/text()').extract_first().strip()[:-2]
        house_id = selector.xpath(
            '//span[@class="mr10"]/text()').extract_first()
        house_name = selector.xpath(
            '//div[@class="h1-tit rel"]/h1/text()').extract_first().strip()
        rent_type = meta_data.get('meta').get('rent_type')
        update_time = selector.xpath(
            '//p[@class="gray9"]/span[2]/text()').extract_first()
        price = selector.xpath(
            '//ul[@class="house-info"]/li[1]/strong/text()').extract_first().strip()
        pay_type = selector.xpath(
            '//ul[@class="house-info"]/li[1]/text()').extract_first().strip()[4:-1]
        house_overview = selector.xpath(
            '//ul[@class="house-info"]/li[2]/text()').extract()
        house_overview = ' '.join(map(lambda x: x.strip(), house_overview))
        community = selector.xpath(
            '//ul[@class="house-info"]/li[3]/a[1]/@href').extract_first()
        community_id = community.split('/')[1] if community else None
        community_name = Parse_special.get_community_name(content)
        is_hezu = selector.xpath(
            '//ul[@class="house-info"]/li[4]/span[1]/text()').extract_first()
        sharing_info, address = Parse_special.get_sharingInfo_and_address(
            is_hezu, content)
        broker_name, is_broker, broker_id, agency_name = Parse_special.get_broker_info(
            content)
        facilities = Parse_special.get_facilities(content)
        image_urls = selector.xpath(
            '//div[@class="bigpicarea"]/div/a/img/@src').extract()
        telephone = Parse_special.get_telephone(content)
        longitude, latitude = Parse_special.get_coordinate(content)
        data = dict(
            city=city,
            district=district,
            zone=zone,
            house_id=house_id,
            house_name=house_name,
            rent_type=rent_type,
            update_time=update_time,
            price=price,
            pay_type=pay_type,
            house_overview=house_overview,
            community_id=community_id,
            community_name=community_name,
            sharing_info=sharing_info,
            address=address,
            is_broker=is_broker,
            broker_id=broker_id,
            agency_name=agency_name,
            broker_name=broker_name,
            telephone=telephone,
            longitude=longitude,
            latitude=latitude,
            facilities=facilities,
            image_urls=image_urls,
            url=current_url,
            crawl_time=Time_utils.getNowTime(),
            p_monitor_id=p_monitor_id,
        )
        item['data'] = data
        yield item
