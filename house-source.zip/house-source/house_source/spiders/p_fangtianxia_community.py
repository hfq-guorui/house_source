# -*- coding: utf-8 -*-

import re
import json
import scrapy
from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy import Selector
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, CompressData

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xian',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wuhan',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nanjing',
}


def get_start_urls():
    start_urls = map(lambda x: 'http://esf.' + x +
                     '.fang.com/housing/', CITYS.values())
    start_urls.remove('http://esf.bj.fang.com/housing/')
    start_urls.insert(0, 'http://esf.fang.com/housing/')
    return start_urls


class PFangtianxiaCommunitySpider(RedisSpider):
    name = 'p_fangtianxia_community'
    redis_key = 'p_fangtianxia_community:start_urls'

    def parse(self, response):
        url = response.url
        selector = Selector(response)
        domain = re.sub(r'com.+', 'com', url)
        community_type_url = selector.xpath(
            '//li[@id="houselist_B03_03"]/a[2]/@href').extract_first()
        url = domain + community_type_url
        yield Request(url, meta={'domain': domain}, callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        community_count = len(selector.xpath(
            '//div[@class="houseList"]/div[@class="list rel"]'))
        for i in range(community_count):
            url = selector.xpath(
                '//div[@class="houseList"]/div[%s]/dl/dd/p[1]/a/@href' % (str(i + 1))).extract_first()
            if not url or not url.startswith('http:'):
                continue
            else:
                community_type = selector.xpath(
                    '//div[@class="houseList"]/div[%s]/dl/dd/p[1]/span/text()' % str(i + 1)).extract_first()
                community_price = selector.xpath(
                    '//div[@class="houseList"]/div[%s]//p[@class="priceAverage"]/span[1]/text()' % str(i + 1)).extract_first()
                sale_count = selector.xpath(
                    '//div[@class="houseList"]/div[%s]//ul[@class="sellOrRenthy clearfix"]/li[1]/a/text()' % str(i + 1)).extract_first()
                rent_count = selector.xpath(
                    '//div[@class="houseList"]/div[%s]//ul[@class="sellOrRenthy clearfix"]/li[2]/a/text()' % str(i + 1)).extract_first()
                # meta_data = json.dumps(
                #     {'meta': {'_id': str(self.p_monitor_id), 'community_type': community_type, 'community_price': community_price, 'sale_count': sale_count, 'rent_count': rent_count}})
                meta_data = json.dumps(
                    {'meta': {'community_type': community_type, 'community_price': community_price, 'sale_count': sale_count, 'rent_count': rent_count}})
                meta_data = CompressData(meta_data).compress()
                if Redis_utils.insert_meta('fangtianxia_community:meta', url, meta_data):
                    Redis_utils.insert_url(
                        'fangtianxia_community:start_urls', url)
        next_url = selector.xpath(
            '//a[@id="PageControl1_hlk_next"]/@href').extract_first()
        if next_url:
            url = domain + next_url
            yield Request(url, meta={'domain': domain}, callback=self.parse_list)
