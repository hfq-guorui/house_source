# -*- coding: utf-8 -*-

import json
import scrapy
from scrapy import Request
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils

CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class GanjiBrokerSpider(RedisSpider):
    name = "ganji_broker"
    allowed_domains = map(lambda x: x + '.ganji.com', CITYS.keys())
    redis_key = 'ganji_broker:start_urls'

    def parse(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        domain = response.url[:19]
        city = selector.xpath(
            '//div[@class="f-crumbs f-w1190"]/a[2]/text()').extract_first()[:-2]
        district = selector.xpath(
            '//ul[@class="f-clear"]/li[@class="item current"]/a/text()').extract_first()
        zone = selector.xpath(
            '//div[@class="fou-list f-clear"]/a[@class="subway-item current"]/text()').extract_first()
        broker_count = len(selector.xpath(
            '//div[@class="f-main-list"]/div').extract())
        for i in range(broker_count):
            broker_id = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//a[@class="broker-name"]/@href' % str(i + 1)).extract_first()
            if broker_id:
                broker_id = broker_id[1:-1]
            broker_name = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//a[@class="broker-name"]/text()' % str(i + 1)).extract_first()
            phone_num = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//p[@class="tel"]/text()' % str(i + 1)).extract_first()
            agency = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//span[@class="bi-text broker-company"]/text()' % str(i + 1)).extract_first()
            service_area = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//span[@class="bi-text"]/a/text()' % str(i + 1)).extract()
            if service_area:
                service_area = '-'.join(service_area)
            service_community = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//span[@class="bi-text broker-xiaoqu"]/a/text()' % str(i + 1)).extract()
            if service_community:
                service_community = '-'.join(service_community)
            house_desc_score = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//ul/li[last()]/span[2]/text()' % str(i + 1)).extract_first()
            service_score = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//ul/li[last()]/span[4]/text()' % str(i + 1)).extract_first()
            credit_score = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//ul/li[last()]/span[6]/text()' % str(i + 1)).extract_first()
            score = selector.xpath(
                '//div[@class="f-main-list"]/div[%s]//div[@class="broker-score fl-l"]/p/b/text()' % str(i + 1)).extract_first()
            data = dict(
                city=city,
                district=district,
                zone=zone,
                broker_id=broker_id,
                broker_name=broker_name,
                phone_num=phone_num,
                agency=agency,
                service_area=service_area,
                service_community=service_community,
                house_desc_score=house_desc_score,
                service_score=service_score,
                credit_score=credit_score,
                score=score,
                url=response.url,
                crawl_time=Time_utils.getNowTime(),
            )
            item['data'] = data
            yield item

        if int(selector.xpath(u'//ul[@class="pageLink clearfix"]/li/a/span/text()="下一页 >"').extract_first()):
            next_url = selector.xpath(
                '//ul[@class="pageLink clearfix"]/li[last()]/a/@href').extract_first()
            yield Request(domain + next_url, meta={'domain': domain}, callback=self.parse)
