# -*- coding: utf-8 -*-

import json
import re
from scrapy import Request, Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData


CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class Parse_special(object):

    @classmethod
    def parse_location(cls, content, rent_type):
        selector = Selector(text=content)
        city = selector.xpath(
            '//div[@class="nav-top-bar fl c_888 f12"]/a[2]/text()').extract_first()
        district = selector.xpath(
            '//div[@class="nav-top-bar fl c_888 f12"]/a[3]/text()').extract_first()
        zone = selector.xpath(
            '//div[@class="nav-top-bar fl c_888 f12"]/a[4]/text()').extract_first()
        if city:
            city = city.strip()[
                :-2] if rent_type == u'整租' else city.strip()[:-3]
        if district:
            district = district.strip()[
                :-2] if rent_type == u'整租' else district.strip()[:-3]
        if zone:
            zone = zone.strip()[
                :-2] if rent_type == u'整租' else zone.strip()[:-3]
        return city, district, zone

    @classmethod
    def get_broker_info(cls, content, broker_url):
        selector = Selector(text=content)
        if broker_url and broker_url.startswith('http://shop.58.com/'):
            broker_id = broker_url.split('/')[-2]
            broker_name = selector.xpath(
                '//*[@id="bigCustomer"]/p[1]/a/text()').extract_first()
        elif broker_url and broker_url.endswith('.5858.com'):
            broker_id = broker_url.split('/')[-1].split('.')[0]
            broker_name = selector.xpath(
                '//*[@id="bigCustomer"]/p[1]/a/text()').extract_first()
        elif broker_url and broker_url.startswith('http://my.58.com'):
            broker_id = broker_url.split('/')[-1]
            broker_name = selector.xpath(
                '//p[@class="agent-name f16 pr"]/a/text()').extract_first()
        else:
            isBroker = 0
            broker_id = None
            broker_name = selector.xpath(
                '//p[@class="agent-name f16 pr"]/a/text()').extract_first()
        return broker_id, broker_name

    @classmethod
    def get_rent_type(cls, content):
        selector = Selector(text=content)
        parsed_content = selector.xpath(
            '//ul[@class="f14"]/li[1]/span[2]/text()').extract_first().encode('utf-8')
        if parsed_content.find('整租') != -1:
            return u'整租'
        elif parsed_content.find('合租') != -1:
            return u'合租'
        else:
            return None

    @classmethod
    def get_coordinate(cls, content):
        try:
            longitude = re.search('"lon":(\d+.\d+)', content).group(1)
            latitude = re.search('"lat":(\d+.\d+)', content).group(1)
        except:
            longitude = None
            latitude = None
        return longitude, latitude

    @classmethod
    def get_house_count(cls, content):
        selector = Selector(text=content)
        parsed_rent_count = selector.xpath(
            '//em[@class="zs c_888 f12"]/a[1]/text()').extract_first()
        parsed_sale_count = selector.xpath(
            '//em[@class="zs c_888 f12"]/a[2]/text()').extract_first()
        try:
            rent_count = int(parsed_rent_count.strip())
            sale_count = int(parsed_sale_count.strip())
        except:
            rent_count = None
            sale_count = None
        return rent_count, sale_count


class Tongcheng58Spider(RedisSpider):

    name = "tongcheng58"
    redis_key = 'tongcheng58:start_urls'

    def __init__(self, *args, **kwargs):
        super(Tongcheng58Spider, self).__init__(*args, **kwargs)
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))

    def parse(self, response):
        '''
        解析房源信息
        '''
        try:
            meta_data = Redis_utils.get_meta('tongcheng58:meta', response.url)
            meta_data = CompressData(meta_data).decompress()
            isBroker = json.loads(meta_data).get('meta').get('is_broker')
        except:
            isBroker = None
        item = HouseSourceItem()
        selector = Selector(response)
        content = response.body_as_unicode()
        house_id = response.url.split('/')[-1].split('.')[0]
        house_name = selector.xpath(
            '//div[@class="house-title"]/h1/text()').extract_first()
        house_info = selector.xpath(
            '//p[@class="house-update-info c_888 f12"]/text()').extract_first()
        if house_info:
            house_info = house_info.strip()
        price = selector.xpath(
            '//span[@class="c_ff552e"]/b/text()').extract_first()
        pay_type = selector.xpath(
            '//span[@class="c_333"]/text()').extract_first()
        rent_type = Parse_special.get_rent_type(content)
        house_type = selector.xpath(
            '//ul[@class="f14"]/li[2]/span[2]/text()').extract_first()
        house_floor = selector.xpath(
            '//ul[@class="f14"]/li[3]/span[2]/text()').extract_first()
        community = selector.xpath(
            '//ul[@class="f14"]/li[4]/span[2]/a/text()').extract_first()
        agency_name = selector.xpath(
            '//p[@class="agent-subgroup f12"]/text()').extract_first()
        city, district, zone = Parse_special.parse_location(content, rent_type)
        traffic = selector.xpath(
            '//ul[@class="f14"]/li[5]/em/text()').extract_first()
        detail_address = selector.xpath(
            '//ul[@class="f14"]/li[6]/span[2]/text()').extract_first()
        if detail_address:
            detail_address = detail_address.strip()
        phone = selector.xpath(
            '//em[@class="phone-num"]/text()').extract_first()
        broker_url = selector.xpath(
            '//p[@class="agent-store f12"]/a[1]/@href').extract_first()
        broker_id, broker_name = Parse_special.get_broker_info(
            content, broker_url)
        longitude, latitude = Parse_special.get_coordinate(content)
        facilities = selector.xpath(
            '//ul[@class="house-disposal"]/li/text()').extract()
        rent_count, sale_count = Parse_special.get_house_count(content)
        service_community = selector.xpath(
            '//div[@class="agent-service-district pa"]/p[2]/a/text()').extract()
        imgage_urls = selector.xpath(
            '//ul[@class="house-pic-list "]/li/img/@lazy_src|//ul[@class="house-pic-list"]/li/img/@lazy_src').extract()
        data = dict(house_id=house_id,
                    house_name=house_name,
                    city=city,
                    district=district,
                    zone=zone,
                    rent_type=rent_type,
                    price=price,
                    pay_type=pay_type,
                    house_type=house_type,
                    house_floor=house_floor,
                    community=community,
                    traffic=traffic,
                    detail_address=detail_address,
                    phone=phone,
                    isBroker=isBroker,
                    broker_id=broker_id,
                    broker_name=broker_name,
                    agency_name=agency_name,
                    house_info=house_info,
                    longitude=longitude,
                    latitude=latitude,
                    facilities=facilities,
                    rent_count=rent_count,
                    sale_count=sale_count,
                    service_community=service_community,
                    imgage_urls=imgage_urls,
                    url=response.url.split('?')[0],
                    crawl_time=Time_utils.getNowTime()
                    )
        item['data'] = data
        yield item
