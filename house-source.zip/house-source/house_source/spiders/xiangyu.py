#-*- coding:utf8 -*-
__author__ = 'GuoRui'

import re

from scrapy import Spider
from scrapy import Selector
from scrapy import Request

from house_source.utils import Time_utils
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils

CITYS = {
    'sh':u'上海' ,
    'hz':u'杭州' ,
    'sz':u'苏州' ,
    'tj':u'天津' ,
    'ty':u'太原' ,
    'cd':u'成都' ,
    'nj':u'南京' ,
    'wx':u'无锡' ,
}

HOUSES_INFO = ['title','house_type','price','area','house_direction','decoration','house_floor','complete_time','floor_type','house_num','publish_time']

def clean_redis():
    '''
    清除上次爬虫产生的redis中的数据
    '''
    Redis_utils.del_keys("xiangyu:dupefilter","xiangyubj:dupefilter")

class Xiangyu(Spider):
    name = "xiangyu"
    allowed_domains = ["m.5i5j.com"]
    start_urls = map(lambda x:"http://m.5i5j.com/%s/rent/x1" % x,CITYS.keys())

    def parse(self,response):
        body = response.body
        meta = response.meta
        sel = Selector(text=body)

        city_prefix = response.url.split('/')[-3]
        city = CITYS.get(city_prefix,None)

        district_list = sel.xpath("//ul[@class='li_sty adr_menu']/li/text()").extract()[1:]
        zone_divide_list = re.findall(r'<!--商圈层不限end-->(.*?)<!--商圈层不限-->',re.sub(r'\s+','',body))
        zone_divide_list.extend(re.findall(r'<!--商圈层不限end-->(.*?)<!--商圈end-->',re.sub(r'\s+','',body)))
        result = []
        website = u'相寓房源'
        for index in range(0,len(zone_divide_list)):
            one_zone_divide = zone_divide_list[index]
            one_district = district_list[index]
            zone_url_list = re.findall(r'"href="(.*?)"',one_zone_divide)
            zone_list = re.findall(r'/x1">(.*?)</a>',one_zone_divide)
            for index in range(0,len(zone_url_list)):
                one_zone_url = "http://m.5i5j.com" + zone_url_list[index].encode('utf8')
                zone = zone_list[index]
                data = dict(
                    city=city,
                    district=one_district,
                    zone=zone,
                    website=website,
                    crawl_time=Time_utils.getNowTime(),
                    batch=Time_utils.getNowDate()
                )
                result.append(data)
                meta["city_prefix"] = city_prefix
                meta["city"] = city
                meta["district"] = one_district
                meta["zone"] = zone
                yield Request(one_zone_url,callback=self.parse_zone_url,meta=meta)

    def parse_zone_url(self,response):
        url = response.url
        body = response.body
        meta = response.meta

        sel = Selector(text=body)
        headers = {
            "Host": "m.5i5j.com",
            "Connection": "keep-alive",
            "Accept": "text/html, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "Accept-Encoding": "gzip, deflate, sdch",
            "Accept-Language": "zh-CN,zh;q=0.8",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36",
        }
        houses_url_list = []
        if "page" not in url:
            houses_url_list = sel.xpath("//ul[@id='rentList']/li/a/@href").extract()
        else:
            houses_url_list = sel.xpath("//li/a/@href").extract()
        if isinstance(houses_url_list,list) and len(houses_url_list):
            for one_house_url in houses_url_list:
                whole_house_url = "http://m.5i5j.com" + one_house_url.encode('utf8')
                yield Request(whole_house_url,callback=self.parse_detail,meta=meta,headers=headers)

        zone_str = re.sub(r'.+rent/','',url)
        zone_str = re.sub(r'/x1','',zone_str)
        next_url = ""
        if "page" not in url:
            next_url = "http://m.5i5j.com/%s/rent/getlist?page=2&pathInfo=%s" % (meta["city_prefix"],zone_str) + "%2Fx1"
        else:
            match_page_num = re.search(r'page=(\d+)&',url)
            if match_page_num:
                page_num = int(match_page_num.group(1)) + 1
                next_url = re.sub(r'page=\d+','page=%s' % str(page_num),url) + "%2Fx1"
        if len(body) > 100:
            yield Request(next_url,callback=self.parse_zone_url,meta=meta,headers=headers)

    def parse_detail(self,response):
        body = response.body
        url = response.url
        meta = response.meta

        item = HouseSourceItem()
        sel = Selector(text=body)

        facilities_list = sel.xpath("//ul[@class='z-icons-box']/li/span/text()").extract()
        imgurl_list = sel.xpath("//div[@class='swiper-wrapper']/div/img/@src").extract()
        people_count_list = sel.xpath("//div[@class='d-look-x']/span[@class='blue-look']/text()").extract()
        people_count = 0
        if isinstance(people_count_list,list) and len(people_count_list):
            people_count = int(people_count_list[0])
        house_name_list = sel.xpath("//div[@class='tithed']/text()").extract()
        house_name = ""
        if isinstance(house_name_list,list) and len(house_name_list):
            house_name = house_name_list[0]
        broker_name_list = sel.xpath("//p[@class='pname']/text()").extract()
        broker_name = ""
        if isinstance(broker_name_list,list) and len(broker_name_list):
            broker_name = broker_name_list[0]
        isBroker = "0"
        if broker_name != "":
            isBroker = "1"
        city = meta["city"]
        district = meta["district"]
        zone = meta["zone"]
        phone_list = sel.xpath("//div[@class='people-lx fl']/a/@href").extract()
        phone = ""
        if isinstance(phone_list,list) and len(phone_list):
            match_phone = re.search(r'tel:(\d+)',phone_list[0])
            if match_phone:
                phone = match_phone.group(1)
        info_dict = {}
        for index in range(2,13):
            house_info_value_list = sel.xpath("//ul[@class='huose-list-x']/li[%s]/span[2]/text()" % str(index)).extract()
            if isinstance(house_info_value_list,list) and len(house_info_value_list):
                house_info_value = house_info_value_list[0]
                info_dict[HOUSES_INFO[index-2]] = house_info_value
        decoration = ""
        if info_dict.has_key("decoration"):
            decoration = info_dict["decoration"]
        data = dict(house_id=info_dict["house_num"],
                    house_name=house_name,
                    title=info_dict["title"],
                    house_type=info_dict["house_type"],
                    price=info_dict["price"],
                    area=info_dict["area"],
                    house_direction=info_dict["house_direction"],
                    decoration=decoration,
                    complete_time=info_dict["complete_time"],
                    house_floor=info_dict["house_floor"],
                    floor_type=info_dict["floor_type"],
                    publish_time=info_dict["publish_time"],
                    city=city,
                    district=district,
                    zone=zone,
                    phone=phone,
                    isBroker=isBroker,
                    broker_name=broker_name,
                    people_count=people_count,
                    facilities=facilities_list,
                    imgurl=imgurl_list,
                    crawl_time=Time_utils.getNowTime(),
                    url=url,
                    )
        item['data'] = data
        yield item





