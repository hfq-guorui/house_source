# -*- coding: utf-8 -*-

import json
import scrapy
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData
from bson.objectid import ObjectId

class LianjiaBrokerSpider(RedisSpider):
    name = "lianjia_broker"
    allow_domains = ['dianpu.lianjia.com']
    redis_key = 'lianjia_broker:start_urls'

    def parse(self, response):
        url = response.url
        try:
            meta_data = Redis_utils.get_meta('lianjia_broker:meta', url)
            meta_data = json.loads(CompressData(meta_data).decompress())
        except:
            pass
        item = HouseSourceItem()
        selector = Selector(response)
        broker_id = response.url.split('/')[-2]
        broker_name = selector.xpath(
            '//div[@class="agent-name clear-fl"]/a[1]/text()').extract_first()
        city = selector.xpath(
            '//div[@class="fl l-txt"]/a[3]/text()').extract_first()[:-5]
        district = selector.xpath(
            '//div[@class="fl l-txt"]/a[4]/text()').extract_first()[:-5]
        zone = selector.xpath(
            '//div[@class="fl l-txt"]/a[5]/text()').extract_first()[:-5]
        shop_name = selector.xpath(
            '//*[@id="mapShow"]/span/text()').extract_first()
        telephone = selector.xpath(
            '//div[@class="achievement"]/span/text()').extract_first().split(':')[1].strip()
        hire_time = selector.xpath(
            '//div[@class="info_bottom"]/p[1]/text()[1]').extract_first().strip()
        history = selector.xpath(
            '//div[@class="info_bottom"]/p[1]/a/text()|//div[@class="info_bottom"]/p[1]/span[2]/text()').extract_first()
        rencent_30days = selector.xpath(
            '//div[@class="info_bottom"]/p[1]/text()[3]|//div[@class="info_bottom"]/p[1]/text()[2]').extract()
        if rencent_30days:
            rencent_30days = rencent_30days[-1]
        achievement = history + ' ' + rencent_30days
        service_zone = selector.xpath(
            '//div[@class="info_bottom"]/p[2]/a/text()').extract()
        service_zones = []
        for i in range(len(service_zone) / 2):
            service_zones.append('-'.join(service_zone[2 * i:2 * i + 2]))
        service_community = selector.xpath(
            '//div[@class="info_bottom"]/p[3]/a/text()').extract()
        service_community = ','.join(service_community)
        # 是否为卖房经纪人
        is_sale_broker = 1 if selector.xpath(
            '//div[@class="info_bottom"]/p[1]/a/text()').extract_first() else 0
        data = dict(
            broker_id=broker_id,
            broker_name=broker_name,
            city=city,
            district=district,
            zone=zone,
            shop_name=shop_name,
            telephone=telephone,
            hire_time=hire_time,
            achievement=achievement,
            service_zones=service_zones,
            service_community=service_community,
            is_sale_broker=is_sale_broker,
            url=url,
            crawl_time=Time_utils.getNowTime(),
        )
        item['data'] = data
        yield item
