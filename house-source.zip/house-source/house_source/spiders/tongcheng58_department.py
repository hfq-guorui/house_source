# -*- coding: utf-8 -*-

import re
import json
from scrapy import Request, Selector
from house_source.items import HouseSourceItem
from scrapy_redis.spiders import RedisSpider
from house_source.utils import Redis_utils, Time_utils, CompressData


CITYS = {
    'bj': u'北京',
    'sh': u'上海',
    'hz': u'杭州',
    'sz': u'深圳',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


def get_coordinate(content):
    try:
        longitude = re.search(
            "____json4fe.lon = \'(\d+.\d+)\'", content).group(1)
        latitude = re.search(
            "____json4fe.lat = \'(\d+.\d+)\'", content).group(1)
    except:
        longitude = None
        latitude = None
    return longitude, latitude


def parse2int(text):
    return int(text) if text.strip().isdigit() else text


class Parse_type(object):
    @classmethod
    def parse_type_1(cls, content):
        selector = Selector(text=content)
        department_name = selector.xpath(
            '//div[@class="housedetail center cf"]/h2/text()').extract_first()
        city = selector.xpath(
            '//div[@class="crumbar"]/a[1]/text()|//div[@class="curmbar"]/a[1]/text()').extract_first()
        if city:
            city = city[:-2]
        district = selector.xpath(
            '//div[@class="crumbar"]/a[2]/text()|//div[@class="curmbar"]/a[2]/text()').extract_first()
        if district:
            district = district[:-2]
        zone = selector.xpath(
            '//div[@class="crumbar"]/a[3]/text()|//div[@class="curmbar"]/a[3]/text()').extract_first()
        if zone:
            zone = zone[:-2]
        update_time = selector.xpath(
            '//div[@class="tags"]/span/text()').extract_first()
        update_time = update_time.split(u'：')[1].strip()
        price = selector.xpath(
            '//div[@class="detail_header"]/span[1]/text()').extract_first()
        area = selector.xpath(
            '//ul[@class="house-info-list"]/li[1]/span/text()').extract_first()
        rent_type = selector.xpath('//h2/text()').extract_first()[1:3]
        hall_room = selector.xpath(
            '//ul[@class="house-info-list"]/li[2]/span/text()').extract_first()
        hall_room = ''.join(hall_room.split(' '))
        floor = selector.xpath(
            '//ul[@class="house-info-list"]/li[3]/span/text()').extract_first()
        address = selector.xpath(
            '//ul[@class="house-info-list"]/li[4]/span/text()').extract_first()
        traffic = selector.xpath(
            '//ul[@class="house-info-list"]/li[5]/span/text()').extract_first()
        department = selector.xpath(
            '//div[@class="apartment-info pa"]/a/span/text()').extract_first()
        phone_num = selector.xpath(
            '//div[@class="detail_headercon"]/div/text()').extract_first()
        image_urls = selector.xpath(
            '//ul[@class="house-picture-list"]/li/img/@lazy_src').extract()
        tags = selector.xpath('//ul[@class="tags-list"]/li/text()').extract()
        house_desc = selector.xpath('//p[@id="desc"]/text()').extract()
        if house_desc:
            house_desc = ' '.join(house_desc).strip()
        department = selector.xpath(
            '//span[@class="name"]/text()').extract_first()
        department_logo_url = selector.xpath(
            '//div[@class="apartment-info pa"]/a/img/@src').extract_first()
        facilities = selector.xpath(
            '//div[@class="house-setup center cf"]/ul/li/text()[2]').extract()
        if facilities:
            facilities = map(lambda x: x.strip(), facilities)
        services = selector.xpath(
            '//div[@class="lifearound center cf"]/ul/li/text()[2]').extract()
        if services:
            services = map(lambda x: x.strip(), services)
        longitude, latitude = get_coordinate(content)
        data = dict(
            department_name=department_name,
            city=city,
            district=district,
            zone=zone,
            update_time=update_time,
            price=price,
            area=area,
            hall_room=hall_room,
            floor=floor,
            address=address,
            traffic=traffic,
            department=department,
            phone_num=phone_num,
            rent_type=rent_type,
            image_urls=image_urls,
            tags=tags,
            house_desc=house_desc,
            department_logo_url=department_logo_url,
            facilities=facilities,
            services=services,
            longitude=longitude,
            latitude=latitude,
            crawl_time=Time_utils.getNowTime(),
        )
        return data

    @classmethod
    def parse_type_2(cls, content):
        selector = Selector(text=content)
        department_name = selector.xpath(
            '//div[@class="describe"]/p[1]/text()').extract_first()
        shop_name = selector.xpath(
            '//div[@class="describe"]/p[2]/text()').extract_first()
        parsed_city = selector.xpath(
            '//div[@class="curmbar"]/a[1]/text()|//div[@class="crumbar"]/a[1]/text()').extract_first()
        city = parsed_city[:-2] if parsed_city else parsed_city
        parsed_district = selector.xpath(
            '//div[@class="curmbar"]/a[2]/text()|//div[@class="crumbar"]/a[1]/text()').extract_first()
        district = parsed_district[:-2] if parsed_district else parsed_district
        parsed_zone = selector.xpath(
            '//div[@class="curmbar"]/a[3]/text()|//div[@class="crumbar"]/a[1]/text()').extract_first()
        zone = parsed_zone[:-2] if parsed_zone else parsed_zone
        house_type = selector.xpath(
            '//span[@class="bt"]/text()').extract_first()
        surplus_count = selector.xpath(
            '//span[@class="houseNum"]/text()').extract_first()
        if surplus_count:
            surplus_count = parse2int(surplus_count[1:-1])
        price = selector.xpath(
            '//div[@class="detai detailMoney"]/span[@class="price"]/text()').extract_first()
        rent_type = u'整租'
        pay_type = selector.xpath(
            '//div[@class="detai detailMoney"]/span[@class="deposit"]/text()').extract_first()
        tags = selector.xpath('//ul[@class="tags-list"]/li/text()').extract()
        hall_room = selector.xpath(
            '//div[@class="detail detailHX"]/span/text()').extract_first()
        area = selector.xpath(
            '//div[@class="detail detailArea"]/span/text()').extract_first()
        direction = selector.xpath(
            '//div[@class="detail detailCX"]/span/text()').extract_first()
        address = selector.xpath(
            '//div[@class="detail detailAddress"]/span/text()').extract_first()
        phone_num = selector.xpath(
            '//div[@class="fd phoneNum"]/text()').extract_first()
        image_urls = selector.xpath(
            '//ul[@id="leftImg"]/li/img/@src').extract()
        house_desc = selector.xpath('//p[@class="desc"]/text()').extract()
        if house_desc:
            house_desc = ' '.join(house_desc).strip()
        facilities = selector.xpath(
            '//div[@class="configure-icon"]/ul/li/text()[2]').extract()
        if facilities:
            facilities = map(lambda x: x.strip(), facilities)
        services = selector.xpath(
            '//div[@class="service"]/ul/li/text()[2]').extract()
        if services:
            services = map(lambda x: x.strip(), services)
        longitude, latitude = get_coordinate(content)
        data = dict(
            department_name=department_name,
            shop_name=shop_name,
            city=city,
            district=district,
            zone=zone,
            house_type=house_type,
            surplus_count=surplus_count,
            price=price,
            rent_type=rent_type,
            pay_type=pay_type,
            tags=tags,
            hall_room=hall_room,
            area=area,
            direction=direction,
            address=address,
            phone_num=phone_num,
            image_urls=image_urls,
            house_desc=house_desc,
            facilities=facilities,
            services=services,
            longitude=longitude,
            latitude=latitude,
            crawl_time=Time_utils.getNowTime()
        )
        return data


class Tongcheng58_departmentSpider(RedisSpider):
    name = "department58"
    allowed_domains = map(lambda x: x + '.58.com', CITYS.keys())
    redis_key = 'department58:start_urls'

    def parse(self, response):
        current_url = response.url
        content = response.body_as_unicode()
        item = HouseSourceItem()
        meta_data = Redis_utils.get_meta('department58:meta', current_url)
        meta_data = json.loads(CompressData(
            meta_data).decompress()).get('meta')
        allow_short_rent = meta_data.get('allow_short_rent')
        rent_monthly = meta_data.get('rent_monthly')
        page_type = meta_data.get('page_type')
        if page_type == 1:
            data = Parse_type.parse_type_1(content)
        else:
            data = Parse_type.parse_type_2(content)
        data['department_id'] = response.url.split('/')[-1].split('.')[0]
        data['allow_short_rent'] = allow_short_rent
        data['rent_monthly'] = rent_monthly
        data['page_type'] = page_type
        data['url'] = current_url
        item['data'] = data
        yield item
