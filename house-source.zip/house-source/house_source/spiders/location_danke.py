# -*- coding: utf-8 -*-
import scrapy
from scrapy import Request, Selector
from house_source.items import HouseSourceItem
from house_source.utils import Time_utils

CITYS = {
    'bj':u'北京' ,
    'sh':u'上海' ,
    'sz':u'深圳' ,
    'hz':u'杭州' ,    
}

class Location_dankeSpider(scrapy.Spider):
    name = "location_danke"
    allowed_domains = ["dankegongyu.com"]
    start_urls = map(lambda x:'http://www.dankegongyu.com/room/' + x, CITYS.keys())
    
    def parse(self, response):
        selector = Selector(response)
        district_urls = selector.xpath(
            '//div[@class="filter_options"]/dl[1]//div/a[position()>1]/@href').extract()
        for url in district_urls:
            yield Request(url,callback=self.parse_zones)

    def parse_zones(self, response):
        selector = Selector(response)
        item = HouseSourceItem()
        city_prefix = response.url.split('/')[-2]
        city = CITYS.get(city_prefix)
        #区域2
        district = selector.xpath('//div[@class="filter_options"]/dl[1]//div[@class="option_list"]/a[@class="onlist"]/text()').extract_first()
        #区域3
        zones = selector.xpath('//div[@class="sub_option_list"]/a[position()>1]/text()').extract()
        website = u'蛋壳公寓'
        result = []
        for zone in zones:
            data = dict(
                city=city,
                district=district,
                zone=zone,
                website=website,
                crawl_time=Time_utils.getNowTime(),
                batch=Time_utils.getNowDate()
            )
            result.append(data)
        if result:
            item['data'] = {'location': result}
            yield item

   