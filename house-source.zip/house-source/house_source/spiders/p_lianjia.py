# -*- coding: utf-8 -*-


import math
import json
from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, CompressData

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PLianjiaSpider(RedisSpider):
    name = "p_lianjia"
    headers = {
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.8"
    }
    redis_key = 'p_lianjia:start_urls'

    def parse(self, response):
        selector = Selector(response)
        current_url = response.url
        house_count = int(selector.xpath(
            '//div[@class="list-head clear"]/h2/span/text()').extract_first())
        house_page = int(math.ceil(house_count / 30.0))
        for i in range(house_page):
            next_url = current_url + 'pg%s/' % str(i + 1)
            yield Request(next_url, headers=self.headers, callback=self.parse_house_list, dont_filter=True)

    def parse_house_list(self, response):
        selector = Selector(response)
        house_urls = selector.xpath(
            '//*[@id="house-lst"]/li/div[2]/h2/a/@href').extract()
        for i in range(len(house_urls)):
            people_count = selector.xpath(
                '//ul[@id="house-lst"]/li[%s]/div[@class="info-panel"]/div[@class="col-2"]/div[@class="square"]/div[1]/span[@class="num"]/text()' % str(i + 1)).extract_first()
            complete_time = selector.xpath(
                '//*[@id="house-lst"]/li[%s]/div[2]/div[1]/div[2]/div/text()[2]' % str(i + 1)).extract_first()
            update_time = selector.xpath(
                '//*[@id="house-lst"]/li[%s]/div[2]/div[2]/div[2]/text()' % str(i + 1)).extract_first()
            parsed_brand = selector.xpath(
                '//ul[@id="house-lst"]/li[%s]//div[@class="ziroomTag zufang_ziroom"]/text()' % str(i + 1)).extract_first()
            brand = u'自如' if parsed_brand else u'链家'
            next_url = house_urls[i]
            meta_data = json.dumps({'meta': {'people_count': people_count,
                                             'complete_time': complete_time, 'update_time': update_time, 'brand': brand}})
            meta_data = CompressData(meta_data).compress()
            if Redis_utils.insert_meta('lianjia:meta', next_url, meta_data):
                Redis_utils.insert_url('lianjia:start_urls', next_url)
