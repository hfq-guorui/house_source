# -*- coding: utf-8 -*-

import json
import scrapy
from scrapy import Request, Selector
from house_source.utils import Redis_utils

CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class LocationTongcheng58Spider(scrapy.Spider):
    name = "location_tongcheng58"
    allowed_domains = map(lambda x: x + '.58.com', CITYS.keys())

    def __init__(self, city=None, *args, **kwargs):
        super(LocationTongcheng58Spider, self).__init__(*args, **kwargs)
        self.city = city
        for city_prefix, city_name in CITYS.iteritems():
            if city_name == self.city:
                self.start_urls = ['http://{}.58.com/chuzu/'.format(
                    city_prefix)]

    def parse(self, response):
        selector = Selector(response)
        domain = response.url[:-7]
        district_urls = selector.xpath(
            '//dl[@class="secitem secitem_fist"]/dd/a[position()>1]/@href').extract()
        district_urls = map(lambda x: domain + x, district_urls)
        for url in district_urls:
            yield Request(url, meta={'domain': domain}, callback=self.parse_zones)

    def parse_zones(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        zones_urls = selector.xpath(
            '//div[@class="arealist"]/a/@href').extract()
        # 有的地区没有三级区域
        if not zones_urls:
            Redis_utils.insert_url('p_tongcheng58:start_urls', response.url)
        else:
            zones_urls = map(lambda x: domain + x, zones_urls)
            Redis_utils.insert_url('p_tongcheng58:start_urls', zones_urls)
