# -*- coding: utf-8 -*-

import math
import json
import scrapy
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, Mongo_utils, CompressData

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class LocationLianjiaCommunitySpider(scrapy.Spider):
    name = "location_lianjia_community"
    headers = {
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.8"
    }

    def __init__(self, city=None, district=None, zone=None, *args, **kwargs):
        super(LocationLianjiaCommunitySpider, self).__init__(*args, **kwargs)
        self.city = city
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        if self.city in CITYS.keys():
            self.start_urls = [
                'https://{}.lianjia.com/xiaoqu/'.format(CITYS.get(self.city))]
        else:
            self.start_urls = map(lambda x: 'https://' +
                                  x + '.lianjia.com/xiaoqu/', CITYS.values())

    def parse(self, response):
        selector = Selector(response)
        domain = response.url[:-8]
        district_urls = selector.xpath(
            '//div[@data-role="ershoufang"]/div/a/@href').extract()
        district_urls = map(lambda x: domain + x, district_urls[:16])
        district_urls.extend(district_urls[16:])
        for url in district_urls:
            yield Request(url, headers=self.headers, meta={'domain': domain}, callback=self.parse_zone, dont_filter=True)

    def parse_zone(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        city_prefix = response.url.split('/')[2].split('.')[0]
        city = CITYS.get(city_prefix)
        district_list = selector.xpath(
            '//div[@class="option-list"]/a[@class="on"]/text()').extract()
        district = ""
        if isinstance(district_list, list) and len(district_list):
            district = district_list[0].strip()
        zones_urls = selector.xpath(
            '//div[@data-role="ershoufang"]/div[2]/a/@href').extract()
        zones_names = selector.xpath(
            '//div[@data-role="ershoufang"]/div[2]/a/text()').extract()
        zones_urls = map(lambda x: domain + x, zones_urls)
        if isinstance(zones_names, list) and len(zones_names):
            zones_info_list = zip(zones_names, zones_urls)
            for one_name_url in zones_info_list:
                zone_name = one_name_url[0]
                zone_url = one_name_url[1]
                data = json.dumps({'city': city, 'district': district,
                                   'zone': zone_name.strip()})
                if Redis_utils.insert_meta('p_lianjia_community:meta', zone_url, data):
                    Redis_utils.insert_url(
                        'p_lianjia_community:start_urls', zone_url)
