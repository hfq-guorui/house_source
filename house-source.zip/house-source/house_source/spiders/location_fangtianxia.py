# -*- coding: utf-8 -*-

import scrapy
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils


CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xian',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wuhan',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nanjing',
}


def get_start_urls():
    start_urls = map(lambda x: 'http://zu.' + x + '.fang.com/', CITYS.values())
    start_urls.remove('http://zu.bj.fang.com/')
    start_urls.insert(0, 'http://zu.fang.com/default.aspx')
    return start_urls


class LocationFangtianxiaSpider(scrapy.Spider):
    name = "location_fangtianxia"
    allowed_domains = ["fang.com"]

    def __init__(self, city=None,*args, **kwargs):
        super(LocationFangtianxiaSpider, self).__init__(city=None,*args, **kwargs)
        self.city = city
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        if self.city == u'北京':
            self.start_urls = ['http://zu.fang.com/default.aspx']
        elif self.city in CITYS.keys():
            self.start_urls = [
                'http://zu.{}.fang.com/'.format(CITYS.get(self.city))]
        else:
            self.start_urls = get_start_urls()

    def parse(self, response):
        selector = Selector(response)
        response_url = response.url
        domain = response_url[
            :-13] if response_url.endswith('default.aspx') else response_url[:-1]
        district_urls = selector.xpath(
            '//div[@class="search-listbox"]/dl[1]/dd/a[position()>1]/@href').extract()
        district_urls = map(lambda x: domain + x, district_urls)
        for url in district_urls:
            yield Request(url, meta={'domain': domain}, callback=self.parse_zones, dont_filter=True)

    def parse_zones(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        zone_urls = selector.xpath(
            '//div[@class="quYu"]/a[position()>1]/@href').extract()
        zone_names = selector.xpath(
            '//div[@class="quYu"]/a[position()>1]/text()').extract()
        if isinstance(zone_urls,list) and len(zone_urls):
            zone_urls = map(lambda x: domain + x, zone_urls)
            for one_zone_url in zone_urls:
                Redis_utils.insert_url(
                        'p_fangtianxia:start_urls', one_zone_url)

