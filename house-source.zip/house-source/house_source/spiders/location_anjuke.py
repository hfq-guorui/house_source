# -*- coding: utf-8 -*-


import scrapy
from scrapy import Request
from scrapy import Selector
from house_source.items import HouseSourceItem
from house_source.utils import Mongo_utils, Time_utils

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class Location_AnjukeSpider(scrapy.Spider):
    name = "location_anjuke"
    allowed_domains = ["zu.anjuke.com"]
    start_urls = map(
        lambda x: 'http://{}.zu.anjuke.com/'.format(x), CITYS.values())

    def parse(self, response):
        selector = Selector(response)
        district_urls = selector.xpath(
            '//div[@class="div-border items-list"]/div[1]/span[@class="elems-l"]/a[position()>1]/@href').extract()
        for url in district_urls:
            yield Request(url, callback=self.parse_zones)

    def parse_zones(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        city = selector.xpath(
            '//*[@id="switch_apf_id_5"]/text()[1]').extract_first().strip()
        district = selector.xpath(
            '//div[@class="items"][1]/span[@class="elems-l"]/a[@class="selected-item"]/text()').extract_first()
        zones = selector.xpath(
            '//div[@class="sub-items"]/a[position()>1]/text()').extract()
        locations = []
        for zone in zones:
            data = dict(
                city=city,
                district=district,
                zone=zone,
                website=u'安居客',
                crawl_time=Time_utils.getNowTime(),
                batch=Time_utils.getNowDate()
            )
            locations.append(data)
        item['data'] = {'location': locations}
        yield item
