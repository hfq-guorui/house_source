# -*- coding: utf-8 -*-

import json
from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, CompressData

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PTongcheng58Spider(RedisSpider):
    name = "p_tongcheng58"
    allowed_domains = map(lambda x: x + '.58.com', CITYS.values())
    redis_key = 'p_tongcheng58:start_urls'

    def parse(self, response):
        domain = response.url[:16]
        selector = Selector(response)
        rent_type_urls = selector.xpath(
            '//div[@class="search_bd"]/dl[4]/dd/a[position()>1]/@href').extract()
        rent_type_urls = map(lambda x: domain + x, rent_type_urls)
        for url in rent_type_urls:
            yield Request(url, meta={'domain': domain}, callback=self.parse_house_type, dont_filter=True)

    def parse_house_type(self, response):
        '''
        抓取个人房源或者是经纪人房源
        '''
        selector = Selector(response)
        domain = response.meta.get('domain')
        urls = selector.xpath('//div[@class="listTitle"]/a/@href').extract()
        if urls:
            urls = urls[2:4]
            next_urls = map(lambda x: domain + x, urls)
            for index, url in enumerate(next_urls):
                is_broker = 0 if index == 0 else 1
                response.meta['is_broker'] = is_broker
                yield Request(url, meta=response.meta, callback=self.parse_price, dont_filter=True)

    def parse_price(self, response):
        '''
        价格筛选
        '''
        price_list = [str(i) for i in range(0, 10001) if i % 500 == 0]
        price_list.append('*')
        for i in range(len(price_list) - 1):
            price_range = '_'.join([price_list[i], price_list[i + 1]])
            next_url = response.url + '?minprice=%s' % price_range
            yield Request(next_url, meta=response.meta, callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):

        selector = Selector(response)
        domain = response.meta.get('domain')
        is_broker = response.meta.get('is_broker')
        meta_data = json.dumps(
            {'meta': {'is_broker': is_broker}})
        meta_data = CompressData(meta_data).compress()
        urls = selector.xpath(
            '//ul[@class="listUl"]/li/div[2]/h2/a/@href').extract()
        for url in urls:
            if url.startswith(domain + '/zufang') or url.startswith(domain + '/hezu') or url.startswith('http://short.58.com') or url.startswith('http://jxjump'):
                if Redis_utils.insert_meta('tongcheng58:meta', url, meta_data):
                    Redis_utils.insert_url('tongcheng58:start_urls', url)
        next_page_url = selector.xpath(
            '//a[@class="next"]/@href').extract_first()
        if next_page_url:
            yield Request(next_page_url, meta={'domain': domain}, callback=self.parse_list)
