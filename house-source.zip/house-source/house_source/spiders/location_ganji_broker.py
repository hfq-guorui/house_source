# -*- coding: utf-8 -*-

import scrapy
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils


CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class LocationGanjiBrokerSpider(scrapy.Spider):
    name = "location_ganji_broker"
    allowed_domains = map(lambda x: x + '.ganji.com', CITYS.keys())

    def __init__(self, city):
        super(LocationGanjiBrokerSpider, self).__init__()
        self.city = city
        for city_prefix, city_name in CITYS.iteritems():
            if city_name == self.city:
                self.start_urls = [
                    'http://{}.ganji.com/zufang/agent/'.format(city_prefix)]

    def parse(self, response):
        selector = Selector(response)
        domain = response.url[:-14]
        district_urls = selector.xpath(
            '//ul[@class="f-clear"]/li[position()>1]/a/@href').extract()
        district_urls = map(lambda x: domain + x, district_urls)
        for url in district_urls:
            yield Request(url, meta={'domain': domain}, callback=self.parse_district)

    def parse_district(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        zone_urls = selector.xpath(
            '//div[@class="fou-list f-clear"]/a/@href').extract()
        if not zone_urls:
            Redis_utils.insert_url('ganji_broker:start_urls', response.url)
        else:
            zone_urls = map(lambda x: domain + x, zone_urls)
            Redis_utils.insert_url('ganji_broker:start_urls', zone_urls)
