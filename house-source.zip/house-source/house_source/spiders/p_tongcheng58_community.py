# -*- coding: utf-8 -*-

import json
from scrapy import Request
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.utils import Redis_utils, CompressData

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PTongcheng58CommunitySpider(RedisSpider):
    name = 'p_tongcheng58_community'
    redis_key = 'p_tongcheng58_community:start_urls'
    allowed_domains = map(lambda x: x + '.58.com', CITYS.values())

    def parse(self, response):
        selector = Selector(response)
        page_count = len(selector.xpath('//table[@class="tbimg"]/tbody/tr'))
        for i in range(page_count):
            url = selector.xpath(
                '//table[@class="tbimg"]/tbody/tr[%s]//li[@class="tli1"]/a/@href' % str(i + 1)).extract_first()
            community_id = selector.xpath(
                '//table[@class="tbimg"]/tbody/tr[%s]/@xiaoquid' % str(i + 1)).extract_first()
            sale_count = selector.xpath(
                '//table[@class="tbimg"]/tbody/tr[%s]//li[@class="tli3"]/span[1]/text()' % str(i + 1)).extract_first()
            rent_count = selector.xpath(
                '//table[@class="tbimg"]/tbody/tr[%s]//li[@class="tli3"]/span[2]/text()' % str(i + 1)).extract_first()
            meta_data = json.dumps(
                {'meta': {'community_id': community_id, 'sale_count': sale_count, 'rent_count': rent_count}})
            meta_data = CompressData(meta_data).compress()
            if Redis_utils.insert_meta('tongcheng58_community:meta', url, meta_data):
                Redis_utils.insert_url('tongcheng58_community:start_urls', url)
        next_pages = selector.xpath(
            '//div[@id="xiaoquPager"]/a[@class="next"]/@href').extract()
        # 58小区的奇葩翻页
        if next_pages:
            for url in next_pages:
                # 千万不能加上dont_filter=True
                yield Request(url, callback=self.parse)
