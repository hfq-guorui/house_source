# -*- coding: utf-8 -*-

import re
import json
import scrapy
from scrapy import Request
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData
from bson.objectid import ObjectId

CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xian': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wuhan': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nanjing': u'南京',
}


class Parse_detail(object):

    @classmethod
    def get_location(cls, content):
        selector = Selector(text=content)
        urls = selector.xpath(
            '//p[@id="agantesfxq_B01_04"]/a/text()').extract()
        locations = map(lambda x: x[:-5], urls[2:5])
        city = locations[0]
        district = locations[1]
        zone = locations[2]
        return city, district, zone

    @classmethod
    def get_community_info(cls, content, type_num):
        '''
        type_num:1 小区基本信息
        type_num:2 小区配套
        '''
        selector = Selector(text=content)
        title = selector.xpath(
            '//div[@class="con_left"]/div[@class="box"][%s]/div[2]/dl/dd/strong/text()' % type_num).extract()
        title = map(lambda x: x.replace(' ', ''), title)
        content_count = len(selector.xpath(
            '//div[@class="con_left"]/div[@class="box"][%s]/div[2]/dl/dd' % type_num))
        contents = []
        for i in range(content_count):
            content1 = selector.xpath(
                '//div[@class="con_left"]/div[@class="box"][%s]/div[2]/dl/dd[%s]/@title' % (type_num, str(i + 1))).extract_first()
            content2 = selector.xpath(
                '//div[@class="con_left"]/div[@class="box"][%s]/div[2]/dl/dd[%s]/span/text()' % (type_num, str(i + 1))).extract_first()
            content3 = selector.xpath(
                '//div[@class="con_left"]/div[@class="box"][%s]/div[2]/dl/dd[%s]/text()' % (type_num, str(i + 1))).extract_first()
            contents.append(content1 or content2 or content3)
        contents = map(lambda x: x.replace(' ', ''), contents)
        base_info = zip(title, contents)
        # 奇葩的dt标签
        if type_num == 2:
            another_title = selector.xpath(
                '//div[@class="con_left"]/div[@class="box"][%s]/div[2]/dl/dt/strong/text()' % type_num).extract()
            another_content = selector.xpath(
                '//div[@class="con_left"]/div[@class="box"][%s]/div[2]/dl/dt/text()' % type_num).extract()
            another_base_info = zip(another_title, another_content)
            if another_base_info:
                base_info += another_base_info
        return base_info


class FangtianxiaCommunitySpider(RedisSpider):
    name = 'fangtianxia_community'
    allowed_domains = ['fang.com']
    redis_key = 'fangtianxia_community:start_urls'

    def parse(self, response):
        selector = Selector(response)
        current_url = response.url
        try:
            meta_data = Redis_utils.get_meta(
                'fangtianxia_community:meta', current_url)
            meta_data = json.loads(CompressData(meta_data).decompress())
            p_monitor_id = ObjectId(meta_data.get('meta').get('_id'))
            price = meta_data.get('meta').get('community_price')
            rent_count = meta_data.get('meta').get('rent_count')
            sale_count = meta_data.get('meta').get('sale_count')
        except:
            p_monitor_id = None
            price = None
            rent_count = None
            sale_count = None
        url = selector.xpath(
            '//div[@class="xqnavN"]/ul/li[2]/a/@href').extract_first()
        yield Request(url, meta={'p_monitor_id': p_monitor_id, 'price': price, 'sale_count': sale_count, 'rent_count': rent_count}, callback=self.parse_detail)

    def parse_detail(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        p_monitor_id = response.meta.get('p_monitor_id')
        price = response.meta.get('price')
        rent_count = response.meta.get('rent_count')
        sale_count = response.meta.get('sale_count')
        current_url = response.url
        content = response.body_as_unicode()
        city, district, zone = Parse_detail.get_location(content)
        community_id = current_url.split('.')[0].split('/')[-1]
        community_name = selector.xpath('//h1/a/text()').extract_first()
        alias = selector.xpath(
            '//span[@class="con_max"]/text()').extract_first()
        browse_count = selector.xpath(
            '//p[@class="W_total_sq"]/span/text()').extract_first()
        price_info = selector.xpath(
            '//div[@class="box detaiLtop mt20 clearfix"]/dl/dd/span/text()').extract()
        if len(price_info) == 3:
            price_month, chain_month, chain_year = price_info
        else:
            price_month = None
            chain_month = None
            chain_year = None
        base_info = Parse_detail.get_community_info(content, 1)
        supporting_facilities = Parse_detail.get_community_info(content, 2)
        data = dict(
            city=city,
            district=district,
            zone=zone,
            community_id=community_id,
            community_name=community_name,
            alias=alias,
            browse_count=browse_count,
            price_month=price_month,
            chain_month=chain_month,
            chain_year=chain_year,
            base_info=base_info,
            supporting_facilities=supporting_facilities,
            price=price,
            rent_count=rent_count,
            sale_count=sale_count,
            url=current_url,
            crawl_time=Time_utils.getNowTime(),
            p_monitor_id=p_monitor_id,
        )
        item['data'] = data
        yield item
