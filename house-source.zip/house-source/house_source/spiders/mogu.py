# -*- coding: utf-8 -*-

import re
import json
import scrapy
from scrapy import Selector
from scrapy import Request
from house_source.items import HouseSourceItem
from house_source.utils import Time_utils


CITYS = {
    'www': u'上海',
    'bj': u'北京',
    'sz': u'深圳',
    'hz': u'杭州',
    'nj': u'南京'
}


class ParseSpecial(object):
    @classmethod
    def get_house_info(cls, content):
        selector = Selector(text=content)
        house_info = selector.xpath(
            '//div[@class="room-rs"]/ul/li[position()>2]/text()').extract()
        temp_list = []
        for i in house_info:
            temp_list.append(i.split(u'：')[-1].strip())
        return temp_list

    @classmethod
    def get_coordinate(cls, content):
        try:
            longitude = re.search('var lng = "(\d+.\d+)";', content).group(1)
            latitude = re.search('var lat = "(\d+.\d+)";', content).group(1)
        except:
            longitude = None
            latitude = None
        return longitude, latitude

    @classmethod
    def get_image_urls(cls, content):
        selector = Selector(text=content)
        html = selector.xpath(
            '//script[@id="swiperTemplate"]/text()').extract_first().strip()
        sel = Selector(text=html)
        image_urls = sel.xpath(
            '//div[@class="swiper-wrapper"]/div/img/@data-src').extract()
        return image_urls


class MoguSpider(scrapy.Spider):
    name = "mogu"
    start_urls = map(
        lambda x: 'http://{}.mogoroom.com/list/'.format(x), CITYS.keys())

    def __init__(self, max_page, *args, **kwargs):
        super(MoguSpider, self).__init__(*args, **kwargs)
        self.max_page = max_page
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        self.start_urls = map(
            lambda x: 'http://{}.mogoroom.com/list/'.format(x), CITYS.keys())

    def parse(self, response):
        domain = response.url[:-6]
        pageCount = self.max_page.get(response.url)
        for i in range(pageCount):
            url = response.url[:-1] + '?page=%s' % str(i + 1)
            yield Request(url, meta={'domain': domain},
                          callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        urls = selector.xpath(
            '//div[@class="panel panel-room"]/ul/li/div/div/h1/a/@href').extract()
        urls = map(lambda x: domain + x, urls)
        for index, url in enumerate(urls):
            department = selector.xpath(
                '//div[@class="panel panel-room"]/ul/li[%s]/div/div/p[last()]/span[2]/text()|//div[@class="panel panel-room"]/ul/li[%s]/div/div/p[last()]/a/text()' % (str(index + 1), str(index + 1))).extract_first()
            tags = selector.xpath(
                '//div[@class="panel panel-room"]/ul/li[%s]/div/div/p[@class="label-group"]/span/text()' % str(index + 1)).extract()
            yield Request(url, meta={'department': department, 'tags': tags},
                          callback=self.parse_detail)

    def parse_detail(self, response):
        selector = Selector(response)
        department = response.meta.get('department')
        tags = response.meta.get('tags')
        content = response.body_as_unicode()
        current_url = response.url
        department_id = selector.xpath(
            '//div[@class="room-rs"]/ul/li[1]/text()[2]').extract_first()
        if department_id:
            department_id = department_id.split(u'：')[-1].strip()
        department_name = selector.xpath(
            '//ul[@class="room-info-wrap"]/li[1]/h1/span/text()').extract_first()
        if department_name:
            department_name = department_name.strip()
        city = selector.xpath(
            '//div[@class="current-city"]/span/text()').extract_first()
        district = selector.xpath(
            '//ol[@class="breadcrumb"]/li[2]/a/text()').extract_first()[:-1]
        community_name = selector.xpath(
            '//ol[@class="breadcrumb"]/li[3]/a/text()').extract_first()
        address = selector.xpath(
            '//span[@class="spacer-m-r10"]/text()').extract_first()
        if address:
            address = address.strip()
        rent_type = selector.xpath(
            '//ul[@class="room-info-wrap"]/li[3]/span[2]/span/text()').extract_first()
        high_quality_house = selector.xpath(
            '//ul[@class="room-info-wrap"]/li[3]/span[3]/span[@class="tx-middle"]/text()').extract_first()
        pay_type = selector.xpath(
            '//ul[@class="room-info-wrap"]/li[4]/div/div/span[1]/text()').extract_first()
        price = selector.xpath(
            '//ul[@class="room-info-wrap"]/li[4]/div/div/span[2]/span[1]/text()').extract_first()
        if price:
            price = price.strip()
        # 押金
        other_fee = selector.xpath(
            '//ul[@class="room-info-wrap"]/li[4]//div[@class="price-items"]/span/text()').extract_first()
        broker_name = selector.xpath(
            '//div[@class="person-wrap"]/div[1]/span/text()').extract_first()
        high_quality_brand = selector.xpath(
            '//li[@class="table-layout brand-title"]//span[@class="lightdark f12"]/text()').extract_first()
        phone_num = selector.xpath(
            '//span[@class="tx-middle roomphone"]/text()').extract_first()
        image_urls = ParseSpecial.get_image_urls(content)
        hall_room, area, house_type, floor = ParseSpecial.get_house_info(
            content)
        house_desc = selector.xpath(
            '//div[@class="color0f121c lh2em word-break"]/text()').extract_first()
        if house_desc:
            house_desc = house_desc.strip()
        longitude, latitude = ParseSpecial.get_coordinate(content)
        result = dict(
            department=department,
            tags=tags,
            department_id=department_id,
            department_name=department_name,
            city=city,
            district=district,
            community_name=community_name,
            address=address,
            rent_type=rent_type,
            # 优质房源
            high_quality_house=high_quality_house,
            pay_type=pay_type,
            price=price,
            other_fee=other_fee,
            broker_name=broker_name,
            # 优选品牌
            high_quality_brand=high_quality_brand,
            phone_num=phone_num,
            image_urls=image_urls,
            hall_room=hall_room,
            area=area,
            house_type=house_type,
            floor=floor,
            house_desc=house_desc,
            longitude=longitude,
            latitude=latitude,
            url=current_url
        )
        # 访问接口获取数据
        room_id = selector.xpath(
            '//a[@class="da-call btn btn-primary"]/@data-rid').extract_first()
        if room_id:
            formData = {'roomId': room_id}
            yield scrapy.FormRequest(url="http://sz.mogoroom.com//pc/loadRoomConfigData", meta={'roomId': room_id, 'data': result}, formdata=formData, callback=self.parse_facilities)

    def parse_facilities(self, response):
        item = HouseSourceItem()
        room_id = response.meta.get('roomId')
        data = response.meta.get('data')
        result = json.loads(response.body_as_unicode())
        facilities = result.get('body').get('content').get('roomConfig')
        result = []
        for facility in facilities:
            flag = facility.get('highlight')
            if flag:
                result.append(facility.get('value'))
        data['facilities'] = result
        data['crawl_time'] = Time_utils.getNowTime()
        item['data'] = {'house': data}
        yield item
