# -*- coding: utf-8 -*-

import re
import json
import scrapy
from scrapy import Request
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData
from bson.objectid import ObjectId


CITYS = {
    'bj': u'北京',
    'jn': u'济南',
    'qd': u'青岛',
    'zz': u'郑州',
    'xa': u'西安',
    'cd': u'成都',
    'cq': u'重庆',
    'wh': u'武汉',
    'hf': u'合肥',
    'cs': u'长沙',
    'nj': u'南京',
}


class Parse_special(object):
    @classmethod
    def get_location(cls, content, rent_type):
        selector = Selector(text=content)
        city = selector.xpath(
            '//div[@class="f-crumbs f-w1190"]/a[3]/text()').extract_first()
        district = selector.xpath(
            '//div[@class="f-crumbs f-w1190"]/a[4]/text()').extract_first()
        zone = selector.xpath(
            '//div[@class="f-crumbs f-w1190"]/a[5]/text()').extract_first()
        if city:
            city = city[:-2] if rent_type == u'整租' else city[:-3]
        if district:
            district = district[:-2] if rent_type == u'整租' else district[:-3]
        if zone:
            zone = zone[:-2] if rent_type == u'整租' else zone[:-3]
        return city, district, zone

    @classmethod
    def get_coordinate(cls, content):
        try:
            parsed_content = re.findall(
                "lnglat\":\"b((\d+.\d+),(\d+.\d+))", content)[0]
            longitude, latitude = parsed_content[1], parsed_content[2]
        except:
            longitude = None
            latitude = None
        return longitude, latitude

    @classmethod
    def get_community_info(cls, content):
        selector = Selector(text=content)
        community_url = selector.xpath(
            '//div[@class="card-info f-fr"]/div/div[3]/p/span[1]/a/@href').extract_first()
        community_id = community_url.split('/')[-2] if community_url else None
        community_id = u'小区id：{}'.format(community_id)
        if community_url:
            community_name = u'小区名称：{}'.format(selector.xpath(
                '//div[@class="district"]/p[@class="title"]/span[1]/text()').extract_first())
            community_price = u'小区价格：{}'.format(selector.xpath(
                '//div[@class="district"]/p[@class="title"]/span[@class="average"]/i/text()').extract_first())
            rent_count = selector.xpath(
                '//div[@class="district"]/p[@class="sub-title"]/a[1]/text()').extract_first()
            second_hand_count = selector.xpath(
                '//div[@class="district"]/p[@class="sub-title"]/a[2]/text()').extract_first()
            # 容积率
            plotRatio = selector.xpath(
                '//div[@class="district"]/ul/li[1]/text()|//div[@class="district"]/ul/li[1]/a[2]/text()').extract_first()
            # 小区地址
            community_address = selector.xpath(
                '//div[@class="district"]/ul/li[2]/text()|//div[@class="district"]/ul/li[2]/a[2]/text()').extract_first()
            # 绿化率
            greeningRate = selector.xpath(
                '//div[@class="district"]/ul/li[3]/text()|//div[@class="district"]/ul/li[3]/a[2]/text()').extract_first()
            # 停车位
            park_count = selector.xpath(
                '//div[@class="district"]/ul/li[5]/text()|//div[@class="district"]/ul/li[5]/a[2]/text()').extract_first()
            # 竣工时间
            complete_time = selector.xpath(
                '//div[@class="district"]/ul/li[6]/text()|//div[@class="district"]/ul/li[6]/a[2]/text()').extract_first()
            suporting = selector.xpath(
                '//div[@class="text"]/p/text()').extract()
            return [community_id, community_name, community_price, rent_count, second_hand_count, plotRatio, community_address, greeningRate, park_count, complete_time, suporting]
        else:
            community_name = selector.xpath(
                '//div[@class="card-info f-fr"]//div[@class="card-item f-clear"][1]/p/span/text()').extract_first()
            if community_name:
                community_name = community_name.strip()
            return [u'小区名称：{}'.format(community_name)]


class GanjiSpider(RedisSpider):
    name = "ganji"
    redis_key = 'ganji:start_urls'
    allowed_domains = map(lambda x: x + '.ganji.com', CITYS.keys())

    def parse(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        content = response.body_as_unicode()
        response_url = response.url
        try:
            meta_data = Redis_utils.get_meta('ganji:meta', response_url)
            meta_data = json.loads(CompressData(meta_data).decompress())
            domain = meta_data.get('meta').get('domain')
            p_monitor_id = ObjectId(meta_data.get('meta').get('_id'))
            rent_type = meta_data.get('meta').get('rent_type')
        except:
            position = response.url.find('com')
            domain = response_url[:position + 3]
            p_monitor_id = None
            rent_type = None
        house_id = response.url.split('/')[-1].split('.')[0]
        house_name = selector.xpath(
            '//p[@class="card-title"]/i/text()').extract_first()
        city, district, zone = Parse_special.get_location(content, rent_type)
        price = selector.xpath('//span[@class="num"]/text()').extract_first()
        pay_type = selector.xpath('//li[@class="type"]/text()').extract_first()
        house_info = selector.xpath(
            '//ul[@class="er-list f-clear"]/li/span[2]/text()').extract()
        house_info = '-'.join(house_info).strip()
        community_info = Parse_special.get_community_info(content)
        address = selector.xpath(
            '//ul[@class="er-list-two f-clear"]/li[2]/span[@class="content"]/a/text()').extract()
        address = '-'.join(address)
        broker_id = selector.xpath(
            '//p[@class="shop"]/a/@href').extract_first()
        if broker_id:
            broker_id = broker_id.split('/')[-2]
        is_broker = 1 if broker_id else 0
        if is_broker:
            agency_name = selector.xpath(
                '//ul[@class="info"]/li[@class="agent-info f-clear"]/p[@class="company"]/text()').extract_first()
        else:
            agency_name = None
        broker_name = selector.xpath(
            '//div[@class="user-info-top"]/p/text()').extract_first()
        if broker_name:
            broker_name = broker_name.strip()
        facilities = selector.xpath(
            '//ul[@class="collocation f-clear"]/li[@class="item"]/p[2]/text()').extract()
        image_urls = selector.xpath(
            '//ul[@class="small-wrap f-clear"]/li/@data-image').extract()
        longitude, latitude = Parse_special.get_coordinate(content)
        phone_num = selector.xpath(
            '//div[@id="full_phone_show"]/@data-phone').extract_first()
        if phone_num:
            phone_num = re.sub(' ', '', phone_num)
        crawl_time = Time_utils.getNowTime()
        data = dict(
            house_id=house_id,
            house_name=house_name,
            city=city,
            district=district,
            zone=zone,
            price=price,
            rent_type=rent_type,
            pay_type=pay_type,
            house_info=house_info,
            community_info=community_info,
            address=address,
            is_broker=is_broker,
            broker_id=broker_id,
            broker_name=broker_name,
            agency_name=agency_name,
            facilities=facilities,
            image_urls=image_urls,
            longitude=longitude,
            latitude=latitude,
            url=response_url,
            phone_num=phone_num,
            crawl_time=crawl_time,
            p_monitor_id=p_monitor_id
        )
        item['data'] = data
        yield item
