# -*- coding: utf-8 -*-

import json
import scrapy
from scrapy_redis.spiders import RedisSpider
from scrapy import Selector
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils
from bson.objectid import ObjectId


class ParseSpecial(object):
    @classmethod
    def get_location(cls, content):
        selector = Selector(text=content)
        city = selector.xpath(
            '//div[@class="p_1180 p_crumbs"]/a[2]/text()').extract_first()
        district = selector.xpath(
            '//div[@class="p_1180 p_crumbs"]/a[3]/text()').extract_first()
        zone = selector.xpath(
            '//div[@class="p_1180 p_crumbs"]/a[4]/text()').extract_first()
        if city:
            city = city[:-2]
        if district:
            district = district[:-2]
        if zone:
            zone = zone[:-2]
        return city, district, zone

    @classmethod
    def get_price(cls, content):
        selector = Selector(text=content)
        price_parsed = selector.xpath(
            '//dl[@class="p_phrase cf"]/dd/strong/span/text()').extract_first()
        try:
            price = float(price_parsed)
        except Exception as e:
            price = price_parsed
        return price

    @classmethod
    def get_community_info(cls, content):
        selector = Selector(text=content)
        community_id = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="litem fl"]/dl[5]/dd/a/@href').extract_first()
        if community_id:
            community_id = community_id.split('/')[-1].split('?')[0]
            community_name = selector.xpath(
                '//div[@class="pinfo"]/div[2]/div[1]/div[@class="litem fl"]/dl[5]/dd/a/text()').extract_first()
        else:
            community_id = None
            community_name = selector.xpath(
                '//div[@class="pinfo"]/div[2]/div[1]/div[@class="litem fl"]/dl[5]/dd/text()').extract_first().strip()
        return community_id, community_name

    @classmethod
    def get_broker_info(cls, content):
        selector = Selector(text=content)
        broker_id = selector.xpath(
            '//div[@class="system-link-track"]/a/@href').extract_first()
        if broker_id:
            broker_id = broker_id.split('/')[-3]
        broker_name = selector.xpath(
            '//h2[@id="broker_true_name"]/text()').extract_first()
        company_url = selector.xpath(
            '//div[@class="broker_name"]/a[1]/@href').extract_first()
        isbroker = 1 if company_url else 0
        return isbroker, broker_id, broker_name

    @classmethod
    def get_agency_info(cls, content, isbroker):
        selector = Selector(text=content)
        agency_id = selector.xpath('//div[@class="broker_name"]/a[1]/@href').extract_first(
        ).split('.')[0].split('/')[-1] if isbroker else None
        agency_name = selector.xpath(
            '//div[@class="broker_name"]/a[1]/text()').extract_first() if isbroker else None
        return agency_id, agency_name

    @classmethod
    def get_shop_info(cls, content, isbroker):
        selector = Selector(text=content)
        shop_id = selector.xpath('//div[@class="broker_name"]/a[2]/@href').extract_first(
        ).split('/')[-2] if isbroker else None
        shop_name = selector.xpath(
            '//div[@class="broker_name"]/a[2]/text()').extract_first() if isbroker else None
        return shop_id, shop_name


class AnjukeSpider(RedisSpider):
    name = "anjuke"
    allowed_domains = ["zu.anjuke.com"]
    redis_key = 'anjuke:start_urls'

    def parse(self, response):
        selector = Selector(response)
        item = HouseSourceItem()
        url = response.url
        try:
            meta_data = json.loads(Redis_utils.get_meta('anjuke:meta', url))
            detail_address = meta_data.get('meta').get('detail_address')
            p_monitor_id = meta_data.get('meta').get('_id')
        except:
            detail_address = None
            p_monitor_id = None
        content = response.body_as_unicode()
        house_id = url.split('/')[-1]
        house_name = selector.xpath(
            '//div[@class="tit cf"]/h3/text()').extract_first()
        city, district, zone = ParseSpecial.get_location(content)
        price = ParseSpecial.get_price(content)
        pay_type = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="litem fl"]/dl[2]/dd/text()').extract_first()
        if pay_type:
            pay_type = pay_type.strip()
        house_type = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="litem fl"]/dl[3]/dd/text()').extract_first()
        rent_type = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="litem fl"]/dl[4]/dd/text()').extract_first()
        community_id, community_name = ParseSpecial.get_community_info(content)
        location = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="litem fl"]/dl[6]/dd/a/text()').extract()
        location = '-'.join(location)
        decoration = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="ritem fr"]/dl[2]/dd/text()').extract_first()
        area = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="ritem fr"]/dl[3]/dd/text()').extract_first()
        direction = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="ritem fr"]/dl[4]/dd/text()').extract_first()
        floor = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="ritem fr"]/dl[5]/dd/text()').extract_first()
        house_type2 = selector.xpath(
            '//div[@class="pinfo"]/div[2]/div[1]/div[@class="ritem fr"]/dl[6]/dd/text()').extract_first()
        isbroker, broker_id, broker_name = ParseSpecial.get_broker_info(
            content)
        telephone = selector.xpath(
            '//div[@class="broker_tel"]/text()').extract_first()
        agency_id, agency_name = ParseSpecial.get_agency_info(
            content, isbroker)
        shop_id, shop_name = ParseSpecial.get_shop_info(content, isbroker)
        extra_info = selector.xpath(
            '//div[@class="text-mute extra-info"]/text()').extract_first()
        data_house = dict(
            house_id=house_id,
            house_name=house_name,
            city=city,
            district=district,
            zone=zone,
            price=price,
            pay_type=pay_type,
            house_type=house_type,
            rent_type=rent_type,
            community_id=community_id,
            community_name=community_name,
            location=location,
            decoration=decoration,
            area=area,
            direction=direction,
            floor=floor,
            house_type2=house_type2,
            isbroker=isbroker,
            broker_id=broker_id,
            broker_name=broker_name,
            telephone=telephone,
            agency_id=agency_id,
            agency_name=agency_name,
            shop_id=shop_id,
            shop_name=shop_name,
            extra_info=extra_info,
            detail_address=detail_address,
            url=url,
            crawl_time=Time_utils.getNowTime(),
            p_monitor_id=ObjectId(p_monitor_id)
        )
        item['data'] = {'house': data_house}
        yield item
