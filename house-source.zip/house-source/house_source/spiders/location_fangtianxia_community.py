# -*- coding: utf-8 -*-

import re
import json
import scrapy
from scrapy import Request
from scrapy import Selector
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, CompressData

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xian',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wuhan',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nanjing',
}


def get_start_urls():
    start_urls = map(lambda x: 'http://esf.' + x +
                     '.fang.com/housing/', CITYS.values())
    start_urls.remove('http://esf.bj.fang.com/housing/')
    start_urls.insert(0, 'http://esf.fang.com/housing/')
    return start_urls


class LocationFangtianxiaCommunitySpider(scrapy.Spider):
    name = 'location_fangtianxia_community'

    def __init__(self, city=None, district=None, zone=None, *args, **kwargs):
        super(LocationFangtianxiaCommunitySpider,
              self).__init__(*args, **kwargs)
        self.city = city
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        if self.city == u'北京':
            self.start_urls = ['http://esf.fang.com/housing/']
        else:
            self.start_urls = [
                'http://esf.{}.fang.com/housing/'.format(CITYS.get(self.city))]

    def parse(self, response):
        selector = Selector(response)
        domain = re.findall(r'http://esf.?\w*.fang.com', response.url)[0]
        district_name_list = selector.xpath(
            '//div[@class="qxName"]/a/text()').extract()
        if isinstance(district_name_list, list) and len(district_name_list):
            for district_name in district_name_list[1:]:
                district_url = selector.xpath(
                    '//div[@class="qxName"]/a[text()="%s"]/@href' % district_name).extract_first()
                url = domain + district_url
                yield Request(url, meta={'domain': domain}, callback=self.parse_zones, dont_filter=True)

    def parse_zones(self, response):
        selector = Selector(response)
        domain = response.meta.get('domain')
        zone_name_list = selector.xpath(
            "//p[@id='shangQuancontain']/a/text()").extract()
        if isinstance(zone_name_list, list) and len(zone_name_list):
            for zone_name in zone_name_list[1:]:
                zone_url = selector.xpath(
                    '//p[@id="shangQuancontain"]/a[text()="%s"]/@href' % zone_name).extract_first()
                url = domain + zone_url
                Redis_utils.insert_url(
                    'p_fangtianxia_community:start_urls', url)
