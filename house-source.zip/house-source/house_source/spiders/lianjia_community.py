# -*- coding: utf-8 -*-

import re
import json
import scrapy
from scrapy import Request
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.items import HouseSourceItem
from house_source.utils import Redis_utils, Time_utils, CompressData
from bson.objectid import ObjectId


class Parse_special(object):
    @classmethod
    def get_coordinate(cls, content):
        try:
            coordinate = re.search(
                'xiaoqu="\[(\d+.\d+),(\d+.\d+)\]', content)
            longitude = coordinate.group(1)
            latitude = coordinate.group(2)
        except:
            longitude = None
            latitude = None
        return longitude, latitude


class LianjiaCommunitySpider(RedisSpider):
    name = "lianjia_community"
    allowed_domains = ["dianpu.lianjia.com"]
    redis_key = 'lianjia_community:start_urls'

    def parse(self, response):
        item = HouseSourceItem()
        selector = Selector(response)
        response_url = response.url
        content = response.body_as_unicode()
        try:
            metadata = Redis_utils.get_meta(
                'lianjia_community:meta', response_url)
            metadata = json.loads(CompressData(metadata).decompress())
            data = metadata.get('meta').get('data')
            data['p_monitor_id'] = ObjectId(metadata.get('meta').get('_id'))
        except:
            data = {}
            p_monitor_id = None
        data['community_id'] = response_url.split('/')[-2]
        data['community_name'] = selector.xpath('//h1/text()').extract_first()
        data['city'] = selector.xpath(
            '//div[@class="xiaoquDetailbreadCrumbs"]/div/a[2]/text()').extract_first()[:-2]
        data['district'] = selector.xpath(
            '//div[@class="xiaoquDetailbreadCrumbs"]/div/a[3]/text()').extract_first()[:-2]
        data['zones'] = selector.xpath(
            '//div[@class="xiaoquDetailbreadCrumbs"]/div/a[4]/text()').extract_first()[:-2]
        data['price'] = selector.xpath(
            '//div[@class="xiaoquPrice clear"]/div/span[1]/text()').extract_first()
        data['complete_time'] = selector.xpath(
            '//div[@class="xiaoquInfo"]/div[1]/span[2]/text()').extract_first()
        data['community_type'] = selector.xpath(
            '//div[@class="xiaoquInfo"]/div[2]/span[2]/text()').extract_first()
        data['property_fee'] = selector.xpath(
            '//div[@class="xiaoquInfo"]/div[3]/span[2]/text()').extract_first()
        data['property_name'] = selector.xpath(
            '//div[@class="xiaoquInfo"]/div[4]/span[2]/text()').extract_first()
        data['developer'] = selector.xpath(
            '//div[@class="xiaoquInfo"]/div[5]/span[2]/text()').extract_first()
        data['building_count'] = selector.xpath(
            '//div[@class="xiaoquInfo"]/div[6]/span[2]/text()').extract_first()
        data['house_count'] = selector.xpath(
            '//div[@class="xiaoquInfo"]/div[7]/span[2]/text()').extract_first()
        broker = selector.xpath(
            '//div[@class="agentTitle clear"]/div[1]/a[1]/@href').extract_first()
        data['broker_id'] = broker.split('/')[-1] if broker else None
        data['broker_name'] = selector.xpath(
            '//div[@class="agentTitle clear"]/div[1]/a[1]/text()').extract_first() if broker else None
        data['image_urls'] = selector.xpath(
            '//ol[@id="overviewThumbnail"]/li/@data-src').extract()
        data['longitude'], data[
            'latitude'] = Parse_special.get_coordinate(content)
        data['address'] = response.xpath(
            '//div[@class="detailHeader fl"]/div[@class="detailDesc"]/text()').extract_first()
        data['url'] = response.url
        data['crawl_time'] = Time_utils.getNowTime()
        item['data'] = data
        yield item
