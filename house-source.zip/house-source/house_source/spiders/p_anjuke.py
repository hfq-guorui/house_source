# -*- coding: utf-8 -*-


import json
import scrapy
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, Mongo_utils

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PAnjukeSpider(scrapy.Spider):
    name = "p_anjuke"
    allowed_domains = ["zu.anjuke.com"]

    def __init__(self, city=None, district=None, zone=None, *args, **kwargs):

        super(PAnjukeSpider, self).__init__(*args, **kwargs)
        self.city = city
        self.district = district
        self.zone = zone
        if self.city in CITYS:
            city_prefix = CITYS.get(self.city)
            self.start_urls = ['http://{}.zu.anjuke.com/'.format(city_prefix)]
        else:
            self.start_urls = map(lambda x: 'http://' + x +
                                  '.zu.anjuke.com/', CITYS.values())

    def parse(self, response):
        self.p_monitor_id = get_p_monitor_id(
            u'安居客', 'p_anjuke', self.city, self.district, self.zone)
        selector = Selector(response)
        if not self.district:
            district_urls = selector.xpath(
                '//div[@class="div-border items-list"]/div[1]/span[@class="elems-l"]/a[position()>1]/@href').extract()
            for url in district_urls:
                yield Request(url, callback=self.parse_zones, dont_filter=True)
        else:
            url = selector.xpath(
                '//div[@class="div-border items-list"]/div[1]/span[@class="elems-l"]/a[text()="%s"]/@href' % self.district).extract_first()
            yield Request(url, callback=self.parse_zones, dont_filter=True)

    def parse_zones(self, response):
        selector = Selector(response)
        if not self.zone:
            zone_urls = selector.xpath(
                '//div[@class="sub-items"]/a[position()>1]/@href').extract()
            for url in zone_urls:
                yield Request(url, callback=self.parse_list, dont_filter=True)

        else:
            url = selector.xpath(
                '//div[@class="sub-items"]/a[text()="%s"]/@href' % self.zone).extract_first()
            yield Request(url, callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):
        selector = Selector(response)
        house_urls = selector.xpath(
            '//div[@class="zu-info"]/h3/a/@href').extract()
        for index, url in enumerate(house_urls):
            detail_address = selector.xpath(
                '//div[@class="list-content"]/div[%s]/div[1]/address/text()' % str(index + 3)).extract()[-1].strip()
            meta_data = json.dumps(
                {'meta': {'detail_address': detail_address, '_id': str(self.p_monitor_id)}})
            if Redis_utils.insert_meta('anjuke:meta', url, meta_data):
                Redis_utils.insert_url('anjuke:start_urls', url)
        next_url = selector.xpath(
            '//div[@class="multi-page"]/a[@class="aNxt"]/@href').extract_first()
        if next_url:
            yield Request(next_url, callback=self.parse_list)
