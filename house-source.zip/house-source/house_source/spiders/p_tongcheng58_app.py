# -*- coding: utf-8 -*-
import json
import scrapy
import requests
from scrapy import Request
from house_source.utils import Redis_utils, Mongo_utils

CITYS = {
    u'北京': 'bj',
    u'上海': 'sh',
    u'杭州': 'hz',
    u'深圳': 'sz',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}

TYPES = {
    u'整租': 'zufang',
    u'合租': 'hezu',
}

BROKER = {
    u'个人': '0',
    u'经纪人': '1',
}


class PTongcheng58appSpider(scrapy.Spider):
    name = "p_tongcheng58_app"
    allowed_domains = map(lambda x: x + '.58.com', CITYS.values())

    def __init__(self, city=None, district=None, zone=None, *args, **kwargs):
        super(PTongcheng58appSpider, self).__init__(*args, **kwargs)
        self.city = city
        self.district = district
        self.zone = zone
        city_prefix = CITYS.get(self.city)
        self.start_urls = [
            'http://app.58.com/api/base/info/city/1/1.0.0.0/{}'.format(city_prefix)]

    def parse(self, response):
        self.p_monitor_id = get_p_monitor_id(
            u'58同城', 'p_tongcheng58_app', self.city, self.district, self.zone)
        try:
            results = json.loads(response.body_as_unicode())
        except:
            return
        result = results.get('result')
        area = result.get('area')
        zones = []
        city_id = area[0].get('pid')
        for i in area:
            if self.zone == i.get('name'):
                zone_id = i.get('id')
                zone_pinyin = i.get('dirname')
                url_prefix = map(lambda x, y: 'https://apphouse.58.com/api/list/' + x + '?tabkey=allcity&action=getListInfo,getFilterInfo,getFormInfo&curVer=7.11.3&ct=filter&localname=bj&os=android&format=json&v=1&geotype=baidu&location=' +
                                 city_id + ',' + zone_id + '&filterParams={"biz":"' + y + '","filterLocal":"' + zone_pinyin + '"}', TYPES.values(), BROKER.values())

                for url in url_prefix:
                    yield Request(url, callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):

        try:
            results = json.loads(response.body_as_unicode())
        except:
            return
        result = results.get('result')
        getListInfo = result.get('getListInfo')
        lastPage = getListInfo.get('lastPage')
        if lastPage == 'false':
            lastPage = False
        elif lastPage == 'true':
            lastPage = True
        city_name = CITYS.get(self.city)
        if 'zufang' in response.url:
            url_pro = 'http://m.58.com/' + city_name + '/zufang/'
            rent_type = u'整租'
        elif 'hezu' in response.url:
            url_pro = 'http://m.58.com/' + city_name + '/hezu/'
            rent_type = u'合租'
        meta_data = json.dumps({'meta': {'city': self.city, 'district': self.district,
                                         'zone': self.zone, 'rent_type': rent_type, '_id': str(self.p_monitor_id)}})
        infolist = getListInfo.get('infolist')
        infoID_list = []
        for i in infolist[1:]:
            infoID = i.get('infoID')
            infoID_list.append(infoID)
        for i in infoID_list:
            url = url_pro + str(i) + 'x.shtml'
            if Redis_utils.insert_meta('tongcheng58_app:meta', url, meta_data):
                Redis_utils.insert_url('tongcheng58_app:start_urls', url)
        if not lastPage:
            if response.url.find('page') != -1:
                page = int(response.url.split('&page=')[-1])
                page += 1
            else:
                urls = response.url + '&page=2'
                page = 1
            if page != 1:
                urls = response.url.split('&page=')[-2] + '&page=' + str(page)
            else:
                pass
            yield Request(urls, callback=self.parse_list, dont_filter=True)
