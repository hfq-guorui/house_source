# -*- coding: utf-8 -*-
import json
import scrapy
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, Mongo_utils
CITYS = {
    u'北京': 'bj',
    u'上海': 'sh',
    u'深圳': 'sz',
    u'杭州': 'hz',
}


class PDankeSpider(scrapy.Spider):
    name = "p_danke"
    allowed_domains = ["dankegongyu.com"]

    def __init__(self, city=None, district=None, zone=None, *args, **kwargs):
        super(PDankeSpider, self).__init__(*args, **kwargs)
        self.city = city
        self.district = district
        self.zone = zone
        if self.city in CITYS:
            city_prefix = CITYS.get(self.city)
            self.start_urls = [
                'http://www.dankegongyu.com/room/{}'.format(city_prefix)]
        else:
            self.start_urls = map(
                lambda x: 'http://www.dankegongyu.com/room/' + x, CITYS.values())

    def parse(self, response):
        self.p_monitor_id = get_p_monitor_id(
            u'蛋壳公寓', 'p_danke', self.city, self.district, self.zone)
        selector = Selector(response)
        if not self.district:
            districts_urls = selector.xpath(
                '//div[@class="option_list"]/a[position()>1]/@href').extract()
            for url in districts_urls:
                yield Request(url, callback=self.parse_zones, dont_filter=True)
        else:
            url = selector.xpath(
                '//div[@class="option_list"]/a[text()="%s"]/@href' % self.district).extract_first()
            yield Request(url, callback=self.parse_zones, dont_filter=True)

    def parse_zones(self, response):
        selector = Selector(response)

        if not self.zone:
            zone_urls = selector.xpath(
                '//div[@class="sub_option_list"]/a[position()>1]/@href').extract()

            for url in zone_urls:
                yield Request(url, callback=self.parse_list, dont_filter=True)
        else:
            url = selector.xpath(
                '//div[@class="sub_option_list"]/a[text()="%s"]/@href' % self.zone).extract_first()
            yield Request(url, callback=self.parse_list, dont_filter=True)

    def parse_list(self, response):
        selector = Selector(response)
        meta_data = json.dumps(
            {'meta': {'district': self.district, 'zone': self.zone, '_id': str(self.p_monitor_id)}})
        detail_urls = selector.xpath(
            '//div[@class="roomlist"]//div[@class="r_lbx"]/a/@href').extract()
        for url in detail_urls:
            if Redis_utils.insert_meta('danke:meta', url, meta_data):
                Redis_utils.insert_url('danke:start_urls', url)
        next_url = selector.xpath(
            '//div[@class="page"]/a[last()]/@href').extract_first()
        if next_url:
            yield Request(next_url, callback=self.parse_list)
