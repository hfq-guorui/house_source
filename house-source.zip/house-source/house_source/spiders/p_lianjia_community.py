# -*- coding: utf-8 -*-

import math
import json
import scrapy
from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy import Selector
from house_source.utils import Redis_utils, CompressData

CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PLianjiaCommunitySpider(RedisSpider):
    name = "p_lianjia_community"
    headers = {
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.8"
    }
    redis_key = 'p_lianjia_community:start_urls'

    def parse(self, response):
        selector = Selector(response)
        current_url = response.url
        community_count = int(selector.xpath(
            '//h2[@class="total fl"]/span/text()').extract_first().strip())
        page_count = int(math.ceil(community_count / 30.0))
        for i in range(page_count):
            next_url = current_url + 'pg%s/' % str(i + 1)
            yield Request(next_url, headers=self.headers, callback=self.parse_community_list, dont_filter=True)

    def parse_community_list(self, response):
        selector = Selector(response)
        current_url = response.url
        community_urls = selector.xpath(
            '//ul[@class="listContent"]/li/a/@href').extract()
        for i in range(len(community_urls)):
            data = {}
            data['volume_30days'] = selector.xpath(
                '/html/body/div[4]/div[1]/ul/li[%s]/div[1]/div[2]/a[1]/text()' % str(i + 1)).extract_first()
            data['rent_count'] = selector.xpath(
                '/html/body/div[4]/div[1]/ul/li[%s]/div[1]/div[2]/a[2]/text()' % str(i + 1)).extract_first()
            data['saling_count'] = selector.xpath(
                '/html/body/div[4]/div[1]/ul/li[%s]/div[2]/div[2]/a/span/text()' % str(i + 1)).extract_first()
            meta_data = json.dumps(
                {'meta': {'data': data}})
            meta_data = CompressData(meta_data).compress()
            if Redis_utils.insert_meta('lianjia_community:meta', community_urls[i], meta_data):
                Redis_utils.insert_url(
                    'lianjia_community:start_urls', community_urls[i])
