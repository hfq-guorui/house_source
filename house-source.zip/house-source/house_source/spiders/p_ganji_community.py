# -*- coding: utf-8 -*-


import json
import scrapy
from scrapy import Request
from scrapy import Selector
from scrapy_redis.spiders import RedisSpider
from house_source.utils import Redis_utils, CompressData


CITYS = {
    u'北京': 'bj',
    u'济南': 'jn',
    u'青岛': 'qd',
    u'郑州': 'zz',
    u'西安': 'xa',
    u'成都': 'cd',
    u'重庆': 'cq',
    u'武汉': 'wh',
    u'合肥': 'hf',
    u'长沙': 'cs',
    u'南京': 'nj',
}


class PGanjiCommunitySpider(RedisSpider):
    name = "p_ganji_community"
    redis_key = 'p_ganji_community:start_urls'
    allowed_domains = map(lambda x: x + '.ganji.com', CITYS.values())

    def parse(self, response):
        domain = response.url[:19]
        selector = Selector(response)
        urls = selector.xpath(
            '//ul[@class="list-style1"]/li//div[@class="info-title"]/a/@href').extract()
        if urls:
            Redis_utils.insert_url('ganji_community:start_urls', urls)
        next_url = selector.xpath(
            '//ul[@class="pageLink clearfix"]/li/a[@class="next"]/@href').extract_first()
        if next_url:
            yield Request(domain + next_url, meta={'domain': domain}, callback=self.parse)
