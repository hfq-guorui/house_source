# coding=utf-8

import base64
import random
from scrapy.exceptions import IgnoreRequest
from scrapy.downloadermiddlewares.retry import RetryMiddleware
from scrapy.downloadermiddlewares.redirect import RedirectMiddleware
from urllib import unquote
from house_source.utils import Redis_utils, Proxis_utils


# 随机使用预定义列表里的 User-Agent类
class RandomUserAgent(object):
    def __init__(self, agents):
        # 使用初始化的agents列表
        self.agents = agents

    @classmethod
    def from_crawler(cls, crawler):
        # 获取settings的USER_AGENT列表并返回
        return cls(crawler.settings.getlist('USER_AGENTS'))

    def process_request(self, request, spider):
        # 随机设置Request报头header的User-Agent
        request.headers.setdefault('User-Agent', random.choice(self.agents))


class ProxyMiddleware(object):
    # overwrite process request
    # def process_request(self, request, spider):
        # Set the location of the proxy
        # l = range(81, 90)
        # l.remove(88)
        # proxy = 'http://vpn.itercast.com:88{}'.format(random.choice(l))
        # request.meta['proxy'] = proxy

    def process_request(self, request, spider):
        Proxis_utils.fetchProxies()
        proxy = Proxis_utils.choiceProxy()
        request.meta['proxy'] = proxy


class CustomMiddleware(object):
    def process_request(self, request, spider):
        last_url = request.url
        if spider.name in ['lianjia', 'lianjia_broker', 'lianjia_community', 'p_lianjia', 'p_lianjia_broker', 'p_lianjia_community']:
            if last_url.startswith('http://captcha'):
                url = unquote(last_url.split('=')[1])
                return request.replace(url=url)
        if spider.name == 'department58' or spider.name == 'location_department58' or spider.name == 'p_department58':
            if last_url.find('firewall') != -1:
                url = unquote(last_url.split('url=')[-1])
                return request.replace(url=url)

        if spider.name == 'tongcheng58' or spider.name == 'p_tongcheng58' or spider.name == 'location_tongcheng58':
            if last_url.find('firewall') != -1:
                url = 'http://{}'.format(unquote(last_url.split('url=')[-1]))
                return request.replace(url=url)
            elif last_url.startswith('http://www.58.com?'):
                raise IgnoreRequest()

        if spider.name == 'tongcheng58_community':
            if last_url.startswith('http://pic2') or last_url.endswith('xiaoqu/'):
                raise IgnoreRequest()

        if spider.name.find('ganji') != -1:
            if last_url.find('firewall') != -1:
                url = unquote(last_url.split('url=')[-1])
                return request.replace(url=url)

        if spider.name=='ganji_community':
            if last_url.endswith('xiaoqu/'):
                raise IgnoreRequest()

class CustomRetryMiddleware(RetryMiddleware):
    def process_response(self, request, response, spider):
        if spider.name in ('location_anjuke', 'anjuke', 'p_anjuke') and (response.url.find('captcha') != -1 or response.url.find('404') != -1):
            url = request.meta.get('redirect_urls')[0]
            request = request.replace(url=url)
            reason = 'crash captcha,retry!'
            return self._retry(request, response, spider) or response
        if spider.name == 'tongcheng58':
            try:
                last_url = request.meta.get('redirect_urls')[0]
                if last_url and (last_url.find('jxjump') != -1 or last_url.find('short') != -1):
                    redis_key = 'tongcheng58:meta'
                    current_url = response.url
                    Redis_utils.rename_key(redis_key, last_url, current_url)
            except:
                return response
        return response
